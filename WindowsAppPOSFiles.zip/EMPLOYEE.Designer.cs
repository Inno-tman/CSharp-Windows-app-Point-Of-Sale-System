﻿
namespace CheckMate_POS
{
    partial class EMPLOYEE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EMPLOYEE));
            this.employeegroupBox = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.streetAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hireDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.actors1 = new CheckMate_POS.Actors();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.searchEmplotyeetextBox1 = new System.Windows.Forms.TextBox();
            this.SearchEmployeelabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.empldtlsgroupBox = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.CityCodetextBox2 = new System.Windows.Forms.TextBox();
            this.Citycodelbl = new System.Windows.Forms.Label();
            this.SurnsmetextBox = new System.Windows.Forms.TextBox();
            this.surnamelabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.P_numbertxtBox = new System.Windows.Forms.Label();
            this.employeeNametextBox = new System.Windows.Forms.TextBox();
            this.CitytextBox = new System.Windows.Forms.TextBox();
            this.EmployeeEmailtextBox = new System.Windows.Forms.TextBox();
            this.employeeAddresstextBox = new System.Windows.Forms.TextBox();
            this.removebutton1 = new System.Windows.Forms.Button();
            this.addbutton1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.actors = new CheckMate_POS.Actors();
            this.employeeTableAdapter = new CheckMate_POS.ActorsTableAdapters.EmployeeTableAdapter();
            this.employeegroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actors1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.empldtlsgroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.actors)).BeginInit();
            this.SuspendLayout();
            // 
            // employeegroupBox
            // 
            this.employeegroupBox.BackColor = System.Drawing.Color.PeachPuff;
            this.employeegroupBox.Controls.Add(this.button1);
            this.employeegroupBox.Controls.Add(this.dataGridView1);
            this.employeegroupBox.Controls.Add(this.pictureBox1);
            this.employeegroupBox.Controls.Add(this.searchEmplotyeetextBox1);
            this.employeegroupBox.Controls.Add(this.SearchEmployeelabel);
            this.employeegroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeegroupBox.Location = new System.Drawing.Point(283, 1);
            this.employeegroupBox.Name = "employeegroupBox";
            this.employeegroupBox.Size = new System.Drawing.Size(1021, 491);
            this.employeegroupBox.TabIndex = 0;
            this.employeegroupBox.TabStop = false;
            this.employeegroupBox.Text = "Eployees List";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Peru;
            this.button1.Location = new System.Drawing.Point(722, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 34);
            this.button1.TabIndex = 11;
            this.button1.Text = "UPDATE";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.streetAddressDataGridViewTextBoxColumn,
            this.cityDataGridViewTextBoxColumn,
            this.cityCodeDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.hireDateDataGridViewTextBoxColumn,
            this.employeeTypeDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.employeeBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(946, 281);
            this.dataGridView1.TabIndex = 5;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // streetAddressDataGridViewTextBoxColumn
            // 
            this.streetAddressDataGridViewTextBoxColumn.DataPropertyName = "Street_Address";
            this.streetAddressDataGridViewTextBoxColumn.HeaderText = "Street_Address";
            this.streetAddressDataGridViewTextBoxColumn.Name = "streetAddressDataGridViewTextBoxColumn";
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            // 
            // cityCodeDataGridViewTextBoxColumn
            // 
            this.cityCodeDataGridViewTextBoxColumn.DataPropertyName = "City_Code";
            this.cityCodeDataGridViewTextBoxColumn.HeaderText = "City_Code";
            this.cityCodeDataGridViewTextBoxColumn.Name = "cityCodeDataGridViewTextBoxColumn";
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            // 
            // hireDateDataGridViewTextBoxColumn
            // 
            this.hireDateDataGridViewTextBoxColumn.DataPropertyName = "Hire_Date";
            this.hireDateDataGridViewTextBoxColumn.HeaderText = "Hire_Date";
            this.hireDateDataGridViewTextBoxColumn.Name = "hireDateDataGridViewTextBoxColumn";
            // 
            // employeeTypeDataGridViewTextBoxColumn
            // 
            this.employeeTypeDataGridViewTextBoxColumn.DataPropertyName = "Employee_Type";
            this.employeeTypeDataGridViewTextBoxColumn.HeaderText = "Employee_Type";
            this.employeeTypeDataGridViewTextBoxColumn.Name = "employeeTypeDataGridViewTextBoxColumn";
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.actors1;
            // 
            // actors1
            // 
            this.actors1.DataSetName = "Actors";
            this.actors1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(902, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // searchEmplotyeetextBox1
            // 
            this.searchEmplotyeetextBox1.Location = new System.Drawing.Point(214, 31);
            this.searchEmplotyeetextBox1.Name = "searchEmplotyeetextBox1";
            this.searchEmplotyeetextBox1.Size = new System.Drawing.Size(388, 24);
            this.searchEmplotyeetextBox1.TabIndex = 2;
            this.toolTip1.SetToolTip(this.searchEmplotyeetextBox1, "Enter the Employee Name");
            this.searchEmplotyeetextBox1.TextChanged += new System.EventHandler(this.searchEmplotyeetextBox1_TextChanged);
            // 
            // SearchEmployeelabel
            // 
            this.SearchEmployeelabel.AutoSize = true;
            this.SearchEmployeelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchEmployeelabel.Location = new System.Drawing.Point(6, 31);
            this.SearchEmployeelabel.Name = "SearchEmployeelabel";
            this.SearchEmployeelabel.Size = new System.Drawing.Size(188, 18);
            this.SearchEmployeelabel.TabIndex = 1;
            this.SearchEmployeelabel.Text = "Search Employee by Name";
            this.SearchEmployeelabel.Click += new System.EventHandler(this.SearchEmployeelabel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Name";
            // 
            // empldtlsgroupBox
            // 
            this.empldtlsgroupBox.BackColor = System.Drawing.Color.PeachPuff;
            this.empldtlsgroupBox.Controls.Add(this.comboBox1);
            this.empldtlsgroupBox.Controls.Add(this.maskedTextBox1);
            this.empldtlsgroupBox.Controls.Add(this.CityCodetextBox2);
            this.empldtlsgroupBox.Controls.Add(this.Citycodelbl);
            this.empldtlsgroupBox.Controls.Add(this.SurnsmetextBox);
            this.empldtlsgroupBox.Controls.Add(this.surnamelabel);
            this.empldtlsgroupBox.Controls.Add(this.label8);
            this.empldtlsgroupBox.Controls.Add(this.dateTimePicker1);
            this.empldtlsgroupBox.Controls.Add(this.label7);
            this.empldtlsgroupBox.Controls.Add(this.P_numbertxtBox);
            this.empldtlsgroupBox.Controls.Add(this.employeeNametextBox);
            this.empldtlsgroupBox.Controls.Add(this.CitytextBox);
            this.empldtlsgroupBox.Controls.Add(this.EmployeeEmailtextBox);
            this.empldtlsgroupBox.Controls.Add(this.employeeAddresstextBox);
            this.empldtlsgroupBox.Controls.Add(this.removebutton1);
            this.empldtlsgroupBox.Controls.Add(this.addbutton1);
            this.empldtlsgroupBox.Controls.Add(this.label4);
            this.empldtlsgroupBox.Controls.Add(this.label3);
            this.empldtlsgroupBox.Controls.Add(this.label2);
            this.empldtlsgroupBox.Controls.Add(this.label1);
            this.empldtlsgroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empldtlsgroupBox.Location = new System.Drawing.Point(1, 1);
            this.empldtlsgroupBox.Name = "empldtlsgroupBox";
            this.empldtlsgroupBox.Size = new System.Drawing.Size(282, 491);
            this.empldtlsgroupBox.TabIndex = 1;
            this.empldtlsgroupBox.TabStop = false;
            this.empldtlsgroupBox.Text = "EMPLOYEE DETAILS";
            this.empldtlsgroupBox.Enter += new System.EventHandler(this.empldtlsgroupBox_Enter);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cashier",
            "Baker",
            "Stock Organiser",
            "Manager Assistant",
            "Cook"});
            this.comboBox1.Location = new System.Drawing.Point(130, 335);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(143, 21);
            this.comboBox1.TabIndex = 28;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(130, 292);
            this.maskedTextBox1.Mask = "(+27) 00 000 0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(143, 20);
            this.maskedTextBox1.TabIndex = 27;
            this.maskedTextBox1.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // CityCodetextBox2
            // 
            this.CityCodetextBox2.Location = new System.Drawing.Point(130, 164);
            this.CityCodetextBox2.MaxLength = 4;
            this.CityCodetextBox2.Name = "CityCodetextBox2";
            this.CityCodetextBox2.Size = new System.Drawing.Size(143, 20);
            this.CityCodetextBox2.TabIndex = 26;
            this.toolTip1.SetToolTip(this.CityCodetextBox2, "Enter the city code");
            this.CityCodetextBox2.TextChanged += new System.EventHandler(this.CityCodetextBox2_TextChanged);
            // 
            // Citycodelbl
            // 
            this.Citycodelbl.AutoSize = true;
            this.Citycodelbl.Location = new System.Drawing.Point(6, 167);
            this.Citycodelbl.Name = "Citycodelbl";
            this.Citycodelbl.Size = new System.Drawing.Size(64, 13);
            this.Citycodelbl.TabIndex = 25;
            this.Citycodelbl.Text = "City_Code";
            // 
            // SurnsmetextBox
            // 
            this.SurnsmetextBox.Location = new System.Drawing.Point(130, 55);
            this.SurnsmetextBox.Name = "SurnsmetextBox";
            this.SurnsmetextBox.Size = new System.Drawing.Size(143, 20);
            this.SurnsmetextBox.TabIndex = 24;
            this.toolTip1.SetToolTip(this.SurnsmetextBox, "Enter the Employee Surname");
            this.SurnsmetextBox.TextChanged += new System.EventHandler(this.SurnsmetextBox_TextChanged);
            // 
            // surnamelabel
            // 
            this.surnamelabel.AutoSize = true;
            this.surnamelabel.Location = new System.Drawing.Point(3, 58);
            this.surnamelabel.Name = "surnamelabel";
            this.surnamelabel.Size = new System.Drawing.Size(56, 13);
            this.surnamelabel.TabIndex = 23;
            this.surnamelabel.Text = "Surname";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 343);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "employeeType";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(67, 379);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(209, 20);
            this.dateTimePicker1.TabIndex = 20;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 379);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "hireDate";
            // 
            // P_numbertxtBox
            // 
            this.P_numbertxtBox.AutoSize = true;
            this.P_numbertxtBox.Location = new System.Drawing.Point(6, 300);
            this.P_numbertxtBox.Name = "P_numbertxtBox";
            this.P_numbertxtBox.Size = new System.Drawing.Size(93, 13);
            this.P_numbertxtBox.TabIndex = 18;
            this.P_numbertxtBox.Text = "Phone_Number";
            // 
            // employeeNametextBox
            // 
            this.employeeNametextBox.Location = new System.Drawing.Point(130, 25);
            this.employeeNametextBox.Name = "employeeNametextBox";
            this.employeeNametextBox.Size = new System.Drawing.Size(143, 20);
            this.employeeNametextBox.TabIndex = 15;
            this.toolTip1.SetToolTip(this.employeeNametextBox, "Enter the Employee Name");
            this.employeeNametextBox.TextChanged += new System.EventHandler(this.employeeNametextBox_TextChanged);
            // 
            // CitytextBox
            // 
            this.CitytextBox.Location = new System.Drawing.Point(130, 126);
            this.CitytextBox.Name = "CitytextBox";
            this.CitytextBox.Size = new System.Drawing.Size(143, 20);
            this.CitytextBox.TabIndex = 13;
            this.toolTip1.SetToolTip(this.CitytextBox, "Enter the City");
            this.CitytextBox.TextChanged += new System.EventHandler(this.CitytextBox_TextChanged);
            // 
            // EmployeeEmailtextBox
            // 
            this.EmployeeEmailtextBox.Location = new System.Drawing.Point(130, 199);
            this.EmployeeEmailtextBox.Name = "EmployeeEmailtextBox";
            this.EmployeeEmailtextBox.Size = new System.Drawing.Size(143, 20);
            this.EmployeeEmailtextBox.TabIndex = 12;
            this.toolTip1.SetToolTip(this.EmployeeEmailtextBox, "enter the employee email");
            this.EmployeeEmailtextBox.TextChanged += new System.EventHandler(this.EmployeeEmailtextBox_TextChanged);
            // 
            // employeeAddresstextBox
            // 
            this.employeeAddresstextBox.Location = new System.Drawing.Point(130, 249);
            this.employeeAddresstextBox.Name = "employeeAddresstextBox";
            this.employeeAddresstextBox.Size = new System.Drawing.Size(143, 20);
            this.employeeAddresstextBox.TabIndex = 11;
            this.toolTip1.SetToolTip(this.employeeAddresstextBox, "enter the employee Adress");
            this.employeeAddresstextBox.TextChanged += new System.EventHandler(this.employeeAddresstextBox_TextChanged);
            // 
            // removebutton1
            // 
            this.removebutton1.BackColor = System.Drawing.Color.Peru;
            this.removebutton1.Location = new System.Drawing.Point(160, 412);
            this.removebutton1.Name = "removebutton1";
            this.removebutton1.Size = new System.Drawing.Size(113, 34);
            this.removebutton1.TabIndex = 10;
            this.removebutton1.Text = "Remove";
            this.removebutton1.UseVisualStyleBackColor = false;
            this.removebutton1.Click += new System.EventHandler(this.removebutton1_Click);
            // 
            // addbutton1
            // 
            this.addbutton1.BackColor = System.Drawing.Color.Peru;
            this.addbutton1.Location = new System.Drawing.Point(6, 412);
            this.addbutton1.Name = "addbutton1";
            this.addbutton1.Size = new System.Drawing.Size(113, 34);
            this.addbutton1.TabIndex = 9;
            this.addbutton1.Text = "Add";
            this.addbutton1.UseVisualStyleBackColor = false;
            this.addbutton1.Click += new System.EventHandler(this.addbutton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "City";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "employeeEmail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "employeeAddress";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // actors
            // 
            this.actors.DataSetName = "Actors";
            this.actors.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // EMPLOYEE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1242, 504);
            this.Controls.Add(this.empldtlsgroupBox);
            this.Controls.Add(this.employeegroupBox);
            this.Name = "EMPLOYEE";
            this.Text = "EMPLOYEE";
            this.Load += new System.EventHandler(this.EMPLOYEE_Load);
            this.employeegroupBox.ResumeLayout(false);
            this.employeegroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actors1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.empldtlsgroupBox.ResumeLayout(false);
            this.empldtlsgroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.actors)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox employeegroupBox;
        private System.Windows.Forms.Label SearchEmployeelabel;
        private System.Windows.Forms.TextBox searchEmplotyeetextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox empldtlsgroupBox;
        private System.Windows.Forms.TextBox employeeNametextBox;
        private System.Windows.Forms.TextBox CitytextBox;
        private System.Windows.Forms.TextBox EmployeeEmailtextBox;
        private System.Windows.Forms.TextBox employeeAddresstextBox;
        private System.Windows.Forms.Button removebutton1;
        private System.Windows.Forms.Button addbutton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label P_numbertxtBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CityCodetextBox2;
        private System.Windows.Forms.Label Citycodelbl;
        private System.Windows.Forms.TextBox SurnsmetextBox;
        private System.Windows.Forms.Label surnamelabel;
       
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Actors actors;
        private Actors actors1;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private ActorsTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn streetAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hireDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
    }
}