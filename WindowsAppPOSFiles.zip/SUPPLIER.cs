﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{


    
    public partial class SUPPLIER : Form
    {
        private decimal Total;
        private int num;
        private string transaction;
        public SUPPLIER()
        {
            InitializeComponent();
            num = 0;
            
        }



        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Manager managerForm = new Manager();
            managerForm.Show();
            this.Hide();
        }

        private void searchSuptextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void SUPPLIER_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'inventory2.Stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.inventory2.Stock);
            // TODO: This line of code loads data into the 'inventory2.Stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter1.Fill(this.inventory2.Stock);
            // TODO: This line of code loads data into the 'inventory1.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter.Fill(this.inventory1.Supplier);
            

            // TODO: This line of code loads data into the 'inventory.InventoryOrder' table. You can move, or remove it, as needed.

            this.WindowState = FormWindowState.Maximized;
        }

        private void supplierNametextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ordergroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void productnametextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void SupplierdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AddSupplierbutton1_Click(object sender, EventArgs e)
            {
                string SupplierName = supplierNametextBox1.Text;
                int SupplierCityCode = int.Parse(tCityCodeextBox7.Text);
                string SupplierAddress = STRAdresstextBox9.Text;
                string SupplierCity = CitytextBox8.Text;
                string employeeEmail = EmailtextBox11.Text;
                string SupplierNumber = TellNumbertextBox10.Text;
                
                try
                {
                    Inventory.SupplierRow newRow = inventory.Supplier.NewSupplierRow();

                    newRow.Company_Name = SupplierName;
                    newRow.Street_Address = SupplierAddress;
                    newRow.City_Name = SupplierCity;
                    newRow.City_Code = SupplierCityCode;
                    newRow.Email_Address = employeeEmail;
                    newRow.Phone_Number = SupplierNumber;
                    
                    inventory.Supplier.AddSupplierRow(newRow);

                    // Update the changes to the database using the TableAdapter
                    supplierTableAdapter.Update(inventory.Supplier);

                    // Optionally, display a message or perform additional actions after saving the data
                    MessageBox.Show("Supplier data saved successfully!");

                // Clear the text boxes after saving the data
                    supplierNametextBox1.Clear();
                    STRAdresstextBox9.Clear();
                    tCityCodeextBox7.Clear();
                    CitytextBox8.Clear();
                    EmailtextBox11.Clear();
                }
                catch (Exception ex)
                {
                    // Handle any exception that occurred during the database update
                    MessageBox.Show("Error saving employee data: " + ex.Message);
                }
            
   
        }

        private void SupplierIDtextBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void EmailtextBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void TellNumbertextBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void detailstab_Click(object sender, EventArgs e)
        {

        }

        private void STRAdresstextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void CitytextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void tCityCodeextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            if (SupplierdataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = SupplierdataGridView1.SelectedRows[0];

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                int employeeID = Convert.ToInt32(selectedRow.Cells[0].Value);
                foreach (DataGridViewRow row in SupplierdataGridView1.Rows)
                {
                    int rowID = Convert.ToInt32(row.Cells[0].Value);
                    if (rowID == employeeID)
                    {
                        SupplierdataGridView1.Rows.Remove(row);
                        break;
                    }
                }
                supplierTableAdapter.Update(inventory1.Supplier);

                MessageBox.Show("Employee data deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ProductName = ProductNametextBox6.Text;
            decimal UnitPrice = decimal.Parse(UnitPricetextBox4.Text);
            int supplierID = int.Parse(suppIDextBox5.Text);
            try
            {
                Inventory.StockRow newRow = inventory2.Stock.NewStockRow();
  
                newRow.Product_Name = ProductName;
                newRow.Unit_Price = UnitPrice;
                newRow.Supplier_ID = supplierID;
                
                inventory2.Stock.AddStockRow(newRow);

                // Update the changes to the database using the TableAdapter
                stockTableAdapter.Update(inventory2.Stock);

                // Optionally, display a message or perform additional actions after saving the data
                MessageBox.Show("Customer data saved successfully!");

                // Clear the text boxes after saving the data
                ProductNametextBox6.Clear();
                UnitPricetextBox4.Clear();
                
            }
            catch (Exception ex)
            {
                // Handle any exception that occurred during the database update
                MessageBox.Show("Error saving customer data: " + ex.Message);
            }
        }

        private void UnitPricetextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ProductsdataGridView2.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = ProductsdataGridView2.SelectedRows[0];

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                int employeeID = Convert.ToInt32(selectedRow.Cells[0].Value);
                foreach (DataGridViewRow row in ProductsdataGridView2.Rows)
                {
                    int rowID = Convert.ToInt32(row.Cells[0].Value);
                    if (rowID == employeeID)
                    {
                        ProductsdataGridView2.Rows.Remove(row);
                        break;
                    }
                }
                stockTableAdapter.Update(inventory2.Stock);

                MessageBox.Show("Employee data deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ordertag_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void QuantitytextBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        private void Addbutton3_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.SelectedRows.Count > 0)
            {
                
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                DialogResult result = MessageBox.Show("Are you sure you want to add this ITem in your Order", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                int employeeID = Convert.ToInt32(selectedRow.Cells[0].Value);
                Total += decimal.Parse(QuantityText.Text) * decimal.Parse(selectedRow.Cells[2].Value.ToString());
                num += 1;
                string order = "     Order Request "+ num + "   ";
                
                if(num > 1)
                {
                    order = " ";
                }
                if (QuantityText.Text == "1")
                {
                    transaction = selectedRow.Cells[1].Value.ToString() + "   x1" + ".........R" + selectedRow.Cells[2].Value.ToString();
                }
                else
                {
                    transaction = selectedRow.Cells[1].Value.ToString() + "   x" + QuantityText.Text + ".........R" + selectedRow.Cells[2].Value.ToString();

                }


                // Set the text field to display the transaction with new lines

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    int rowID = Convert.ToInt32(row.Cells[0].Value);
                    if (rowID == employeeID)
                    {
                        totalTextBox.Text = Total.ToString();
                        lastHope.Items.Add(order);
                        lastHope.Items.Add (transaction);//.Replace("\n", Environment.NewLine);

                        break;
                    }
                }
                stockTableAdapter.Update(inventory2.Stock);

            }
            else
            {
                MessageBox.Show("Select Row to Add Products");
            }
        }

        private void QuantityText_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            lastHope.Items.Add("******************************************************");
            lastHope.Items.Add("**********************Total***************************");
            lastHope.Items.Add("R" + Total.ToString());
            lastHope.Items.Add("******************************************************");

            DateTime currentDate = DateTime.Now;
            string dateString = currentDate.ToString("yyyy-MM-dd"); 

            lastHope.Items.Add("DATE:"  + dateString);

        }

        private void SupplierdataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
