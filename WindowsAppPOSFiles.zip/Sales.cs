﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class Sales : Form
    {
        public Sales()
        {
            InitializeComponent();
            
        }

        private void Sales_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'order7.ProductsOrder7' table. You can move, or remove it, as needed.
            this.productsOrder7TableAdapter.Fill(this.order7.ProductsOrder7);
            // TODO: This line of code loads data into the 'order7.OrderTable7' table. You can move, or remove it, as needed.
            this.orderTable7TableAdapter.Fill(this.order7.OrderTable7);
            // TODO: This line of code loads data into the 'saless.ProductsOrder' table. You can move, or remove it, as needed.
            this.productsOrderTableAdapter.Fill(this.saless.ProductsOrder);
            // TODO: This line of code loads data into the 'salesData.Sales' table. You can move, or remove it, as needed.
            this.salesTableAdapter.Fill(this.salesData.Sales);

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
           // salesTableAdapter.SearchByDate(salesData.Sales, dateTimePicker1.Value.ToString());
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Manager m = new Manager();
            m.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            orderTable7TableAdapter.SearchBySaleDate(order7.OrderTable7, dateTimePicker1.Text.ToString(), dateTimePicker2.Text.ToString());
            productsOrder7TableAdapter.SearchSaleByDate(order7.ProductsOrder7, dateTimePicker1.Text.ToString(), dateTimePicker2.Text.ToString());
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
