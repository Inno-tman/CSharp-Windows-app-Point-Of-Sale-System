﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class Manager : Form
    {
        public Manager()
        {
            InitializeComponent();
        }

        private void txtEmailBody_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmailSubject_TextChanged(object sender, EventArgs e)
        {

        }

       

        private void button5_Click(object sender, EventArgs e)
        {

          
        }

        private void AddEmployeeBTN_Click(object sender, EventArgs e)
        {
            this.Hide();
            // Create an instance of the EMPLOYEE form
            EMPLOYEE employeeForm = new EMPLOYEE();

            // Show the EMPLOYEE form
            employeeForm.Show();

        }

        private void ProductsListBox_Enter(object sender, EventArgs e)
        {

        }

        private void RemainingBTN_Click(object sender, EventArgs e)
        {
            ProductsListBox.Show();
            
        }

        private void addSupplierBTN_Click(object sender, EventArgs e)
        {
            SUPPLIER supForm = new SUPPLIER();
            supForm.Show();
            this.Hide();
        }

        private void IteamSearched_TextChanged(object sender, EventArgs e)
        {
            productTableAdapter.SearchByDescription(products.Product, IteamSearched.Text);
        }
        private void Manager_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'products.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.products.Product);
            

            // Set the form to run in maximized mode
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Log Out?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            CAFE CafeForm = new CAFE();
            CafeForm.Show();
            this.Hide();
        }

        private void salesButton_Click(object sender, EventArgs e)
        {
            Sales sales = new Sales();
            sales.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            int Quant = int.Parse(addQuantity.Text.ToString());
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int rowIndex = dataGridView1.SelectedRows[0].Index; // Get the index of the selected row
                    int newQuantity = int.Parse(addQuantity.Text.ToString()); // Get the new quantity value from a UI element, replace with your actual control

                    Products.ProductRow rowToUpdate = products.Product[rowIndex];
                    rowToUpdate.Quantity += newQuantity;

                    productTableAdapter.Update(rowToUpdate);
                    addQuantity.Clear();

                    // Optionally, you can refresh the DataGridView or any other UI component here
                }
                else
                {
                    MessageBox.Show("Please select a row to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Quantity data: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            CAFE c = new CAFE();
            c.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
