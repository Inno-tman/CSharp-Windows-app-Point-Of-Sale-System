﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class CustomerDetails : Form
    {
        public CustomerDetails()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            EmployeeHome home = new EmployeeHome();
            this.Hide();
            home.Show();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CustomerDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'actors.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.actors.Customer);
            this.WindowState = FormWindowState.Maximized;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            customerTableAdapter.SearchByName(actors.Customer, textBox1.Text);
        }

        private void NametextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void SurnametextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void EmailtextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdresstextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

            private void GendertextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void ADDButton_Click(object sender, EventArgs e)
        {
            string customerName = NametextBox4.Text;
            string customerSurname = SurnametextBox5.Text;
            string customerAddress = AdresstextBox1.Text;
            string customerEmail = EmailtextBox6.Text;
            string customerNumber = maskedTextBox1.Text;
            string gender = comboBox1.Text;
            DateTime dateOfBirth = dateTimePicker1.Value;

            // Validate gender field
            if (gender != "Male" && gender != "Female")
            {
                MessageBox.Show("Invalid gender value. Please select 'Male' or 'Female'.");
                return;
            }

            // Validate email field
            if (!customerEmail.Contains("@"))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email address.");
                return;
            }

            try
            {
                Actors.CustomerRow newRow = actors.Customer.NewCustomerRow();

                newRow.Name = customerName;
                newRow.Surname = customerSurname;
                newRow.Address = customerAddress;
                newRow.Email = customerEmail;
                newRow.Phone_Number = customerNumber;
                newRow.Date_Of_Birth = dateOfBirth;
                newRow.Gender = gender;
                actors.Customer.AddCustomerRow(newRow);

                // Update the changes to the database using the TableAdapter
                customerTableAdapter.Update(actors.Customer);

                // Optionally, display a message or perform additional actions after saving the data
                MessageBox.Show("Customer data saved successfully!");

                // Clear the text boxes after saving the data
                NametextBox4.Clear();
                SurnametextBox5.Clear();
                AdresstextBox1.Clear();
                EmailtextBox6.Clear();
                maskedTextBox1.Clear();
            }
            catch (Exception ex)
            {
                // Handle any exception that occurred during the database update
                MessageBox.Show("Error saving customer data: " + ex.Message);
            }

        }

        private void Removebutton1_Click(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView3.SelectedRows[0];

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                int customerID = Convert.ToInt32(selectedRow.Cells[0].Value);
                foreach (DataGridViewRow row in dataGridView3.Rows)
                {
                    int rowID = Convert.ToInt32(row.Cells[0].Value);
                    if (rowID == customerID)
                    {
                        dataGridView3.Rows.Remove(row);
                        break;
                    }
                }
                customerTableAdapter.Update(actors.Customer);

                MessageBox.Show("Employee data deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void updatebutton_Click(object sender, EventArgs e)
        {
            string name = NametextBox4.Text;
            string Surname = SurnametextBox5.Text;
            string Address = AdresstextBox1.Text;
            string MobileNO= maskedTextBox1.Text;
            string email = EmailtextBox6.Text;
            string gender = comboBox1.Text;



            try
            {
                if (dataGridView3.SelectedRows.Count > 0)
                {
                    int rowIndex = dataGridView3.SelectedRows[0].Index;
                    string newName = NametextBox4.Text.ToString();
                    string newSurname = SurnametextBox5.Text.ToString();
                    string newGender = comboBox1.Text.ToString();
                    string newAdress = AdresstextBox1.Text.ToString();
                    string newEmail = EmailtextBox6.Text.ToString();
                    Actors.CustomerRow Update = actors.Customer[rowIndex];
                    if (NametextBox4.Text.Length > 0)
                    {
                        Update.Name = newName;
                    }
                    else if (SurnametextBox5.Text.Length > 0)
                    {
                        Update.Surname = newSurname;

                    }
                    else if (comboBox1.Text.Length > 0)
                    {
                        Update.Gender = newGender;

                    }
                    else if (AdresstextBox1.Text.Length > 0)
                    {
                        Update.Address = newAdress;
                    }
                    else if (EmailtextBox6.Text.Length > 0)
                    {
                        Update.Email = newEmail;

                    }

                    customerTableAdapter.Update(Update);
                    NametextBox4.Clear();
                    //SurnametextBox5.Clear();
                    AdresstextBox1.Clear();
                    EmailtextBox6.Clear();




                }
                else
                {
                    MessageBox.Show("Please select a row to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Quantity data: " + ex.Message);
            }

        }
    }
    
}
