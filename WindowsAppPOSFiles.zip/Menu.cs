﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class Menu : Form
    {
        private decimal Total;
        private string transaction;
        private int num;
        private decimal discount;
        private string order;
        private int OrderID = 1;
        private decimal tot;
        private decimal totalOrder = 0;

        public string NAME { get; set; }
        public string SURNAME { get; set; }
        public string ID { get; set; }
        public string EMAIL { get; set; }
        public string DATE { get; set; }
        public string PHONE { get; set; }
        public string ADDRESS { get; set; }
        public string POSTAL_CODE { get; set; }



        public Menu()
        {
            InitializeComponent();
            num = 0;
            order = "    CHECKMATE CAFE'    ";
            slip.Items.Add(order);


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.Dock = DockStyle.Bottom;
            EmployeeHome home = new EmployeeHome();
            home.Show();
            this.Hide();
        }
        private int GenerateUniqueOrderID()
        {
            int generatedOrderID = OrderID;

            // Check if the generatedOrderID is already in use in ProductsOrder table
            while (order7.ProductsOrder7.Any(po => po.OrderID == generatedOrderID))
            {
                generatedOrderID++;
            }

            // Check if the generatedOrderID is already in use in OrderTable1 table
            while (order7.OrderTable7.Any(ot => ot.OrderID == generatedOrderID))
            {
                generatedOrderID++;
            }

            return generatedOrderID;
        }


        // Define a flag to track whether payment has been processed
        private bool paymentProcessed = false;

        private void button1_Click(object sender, EventArgs e)
        {
            if (Total == 0)
            {
                MessageBox.Show("No items in the slip. Please add items before processing payment.");
                return; // Exit the method to prevent processing
            }
            decimal change = decimal.Parse(payBox.Text) - Total;
            changeBox.Text = "R"+change.ToString();

            if (decimal.Parse(payBox.Text) >= Total)
            {
                // Create a copy of the items in the slip
                List<string> slipItemsCopy = new List<string>(slip.Items.Cast<string>());

                // Clear the current contents of the slip
                slip.Items.Clear();

                // Add header and items
                slip.Items.Add("****************************************************");
                slip.Items.Add("****************** RECEIPT *************************");
                slip.Items.Add("****************************************************");
                slip.Items.Add($"Cashier: {NAME} {SURNAME}");
                slip.Items.Add($"Order Number: {OrderID}");
                slip.Items.Add($"Date: {DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}");
                slip.Items.Add("****************************************************");

                // Add purchased items from the copied list
                foreach (var item in slipItemsCopy)
                {
                    slip.Items.Add(item.ToString());
                }

                slip.Items.Add("****************************************************");

                // Calculate and display VAT (assuming a VAT rate of 10%)
                decimal vat = Total * 0.15m;
                decimal subtotal = Total - vat;

                slip.Items.Add($"Subtotal: {subtotal:C}");
                slip.Items.Add($"VAT (15%): {vat:C}");
                slip.Items.Add($"Total: {Total:C}");
                slip.Items.Add($"Paid Amount: {payBox.Text:C}");
                slip.Items.Add($"Change: {change:C}");

                // Check if a discount applies (Total > 250)
                if (Total > 250)
                {
                    discount = Total * 0.10m;
                    Total = Total - discount;
                    slip.Items.Add($"Discount (10%): -{discount:C}");
                }

                slip.Items.Add("****************************************************");
                slip.Items.Add("\n \n \n");

                // Insert the sale into your database
                DateTime currentDate = DateTime.Now;
                string dateString = currentDate.ToString("yyyy-MM-dd");
                salesTableAdapter.InsertSale(currentDate.ToString(), Total);

                // Reset the total and display the discount (if applicable)
                DiscounttextBox.Text = "R"+discount.ToString();
                Total = 0;

                // Set the paymentProcessed flag to true
                paymentProcessed = true;

                // Disable interaction with the slip ListBox
                slip.Enabled = false;
            }
            else
            {
                MessageBox.Show("Insufficient Funds");
            }
        }



        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            changeBox.Text = "";
            payBox.Text = "";
            totalTextBox.Text = "";
            DiscounttextBox.Text = "";
            slip.Items.Clear();
            slip.Enabled = true;
            slip.Items.Add("    CHECKMATE CAFE'    ");




        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Fruits" || comboBox1.Text == "Bakery" || comboBox1.Text == "Desserts" || comboBox1.Text == "Beverages" || comboBox1.Text == "Fast Food")
            {
                productTableAdapter.SearchByCategory(products.Product, comboBox1.Text);

            }
            else
            {

                productTableAdapter.FillByQ(products.Product);
            }

        }

        private void Menu_Load(object sender, EventArgs e)
        {



        }

        private void Menu_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'order7.ProductsOrder7' table. You can move, or remove it, as needed.
            this.productsOrder7TableAdapter.Fill(this.order7.ProductsOrder7);
            // TODO: This line of code loads data into the 'order7.OrderTable7' table. You can move, or remove it, as needed.
            this.orderTable7TableAdapter.Fill(this.order7.OrderTable7);
            // TODO: This line of code loads data into the 'order6.ProductsOrder6' table. You can move, or remove it, as needed.
            this.productsOrder6TableAdapter.Fill(this.order6.ProductsOrder6);
            // TODO: This line of code loads data into the 'order6.OrderTable6' table. You can move, or remove it, as needed.
            this.orderTable6TableAdapter.Fill(this.order6.OrderTable6);
            // TODO: This line of code loads data into the 'order5.ProductsOrder5' table. You can move, or remove it, as needed.

            // TODO: This line of code loads data into the 'order1.OrderTable1' table. You can move, or remove it, as needed.
            this.orderTable1TableAdapter.Fill(this.order1.OrderTable1);

            // TODO: This line of code loads data into the 'saless.ProductsOrder' table. You can move, or remove it, as needed.
            this.productsOrderTableAdapter.Fill(this.saless.ProductsOrder);
            // TODO: This line of code loads data into the 'salesData.Sales' table. You can move, or remove it, as needed.
            this.salesTableAdapter.Fill(this.salesData.Sales);
            // TODO: This line of code loads data into the 'products.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.products.Product);
            this.WindowState = FormWindowState.Maximized;




        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            productTableAdapter.SearchByDescription(products.Product, textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (paymentProcessed)
            {
                // Prompt the user to reset the slip ListBox
                DialogResult resetConfirmation = MessageBox.Show("Payment has been processed. Do you want to reset the slip?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resetConfirmation == DialogResult.Yes)
                {
                    // Clear the slip ListBox and reset the paymentProcessed flag
                    slip.Items.Clear();
                    slip.Items.Add("    CHECKMATE CAFE'    ");
                    changeBox.Text = "";
                    payBox.Text = "";
                    totalTextBox.Text = "";
                    DiscounttextBox.Text = "";
                    paymentProcessed = false;
                    slip.Enabled = true; // Re-enable interaction with the ListBox
                }
            }
            else
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                    int employeeID = Convert.ToInt32(selectedRow.Cells[0].Value);
                    decimal unitPrice = decimal.Parse(selectedRow.Cells[3].Value.ToString());
                    int quantityToAdd = int.Parse(QuantityText.Text);

                    if (int.Parse(selectedRow.Cells[4].Value.ToString()) > 0 &&
                        quantityToAdd <= int.Parse(selectedRow.Cells[4].Value.ToString()))
                    {
                        string productName = selectedRow.Cells[2].Value.ToString();
                        bool found = false;

                        // Iterate through the items in the slip ListBox
                        for (int i = 0; i < slip.Items.Count; i++)
                        {
                            string slipItem = slip.Items[i].ToString();
                            if (slipItem.Contains(productName))
                            {
                                found = true;
                                // Extract the existing quantity from the existing transaction
                                string[] parts = slipItem.Split(new string[] { "x" }, StringSplitOptions.None);
                                if (parts.Length == 2)
                                {
                                    int existingQuantity = int.Parse(parts[1].Trim().Split(' ')[0]) + quantityToAdd;
                                    decimal newTotal = unitPrice * existingQuantity;
                                    // Calculate the number of spaces needed for the product name
                                    int productNameSpaces = 30 - productName.Length;
                                    // Update the existing transaction in the slip with equal spacing
                                    slip.Items[i] = $"{productName}{new string(' ', productNameSpaces)} x{existingQuantity} R{newTotal:F2}";
                                    break;
                                }
                            }
                        }

                        if (!found)
                        {
                            // Add the new product to the slip with equal spacing
                            decimal tot = unitPrice * quantityToAdd;
                            // Calculate the number of spaces needed for the product name
                            int productNameSpaces = 30 - productName.Length;
                            transaction = $"{productName}{new string(' ', productNameSpaces)} x{quantityToAdd} R{tot:F2}";
                            slip.Items.Add(transaction);
                        }

                        // Update the stock quantity in the DataGridView
                        int newStockQuantity = int.Parse(selectedRow.Cells[4].Value.ToString()) - quantityToAdd;
                        products.Product.Rows[selectedRow.Index]["Quantity"] = newStockQuantity;


                        // Update the total
                        Total += unitPrice * quantityToAdd;
                        totalTextBox.Text = "R"+Total.ToString();
                    }
                    else
                    {
                        MessageBox.Show($"{selectedRow.Cells[2].Value.ToString()} is not available in stock, please contact manager");
                    }
                    productTableAdapter.Update(products.Product);
                }
                else
                {
                    MessageBox.Show("Select a row to add products");
                }
            }
        }






        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            int selectedIndex = slip.SelectedIndex;

            if (selectedIndex >= 0 && slip.Items[selectedIndex].ToString() != "    CHECKMATE CAFE'    ")
            {
                string transactionToRemove = slip.SelectedItem.ToString();

                DialogResult result = MessageBox.Show("Are you sure you want to delete this transaction?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    slip.Items.RemoveAt(selectedIndex);
                }
            }
            else
            {
                MessageBox.Show("Please select a transaction to delete from the ListBox.");
            }
        }




        private void QuantityText_TextChanged(object sender, EventArgs e)
        {

        }

        private void DiscounttextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            EmployeeHome h = new EmployeeHome();
            h.name = NAME;
            h.surname = SURNAME;
            h.phone = PHONE;
            h.postal_Code = POSTAL_CODE;
            h.ID = ID;
            h.address = ADDRESS;
            h.date = DATE;
            h.email = EMAIL;
            h.Show();
        }

        private void slip_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void totalTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void test_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
