﻿

namespace CheckMate_POS
{
    partial class SUPPLIER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SUPPLIER));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.detailstab = new System.Windows.Forms.TabPage();
            this.ProductsgroupBox1 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.QuantitytextBox14 = new System.Windows.Forms.TextBox();
            this.ProductsdataGridView2 = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventory2 = new CheckMate_POS.Inventory();
            this.SearchProdtextBox2 = new System.Windows.Forms.TextBox();
            this.SuppliergroupBox1 = new System.Windows.Forms.GroupBox();
            this.SupplierdataGridView1 = new System.Windows.Forms.DataGridView();
            this.supplierIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companyNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.streetAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventory1 = new CheckMate_POS.Inventory();
            this.searchSuptextBox1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.SupplierIDtextBox12 = new System.Windows.Forms.TextBox();
            this.EmailtextBox11 = new System.Windows.Forms.TextBox();
            this.TellNumbertextBox10 = new System.Windows.Forms.TextBox();
            this.STRAdresstextBox9 = new System.Windows.Forms.TextBox();
            this.CitytextBox8 = new System.Windows.Forms.TextBox();
            this.tCityCodeextBox7 = new System.Windows.Forms.TextBox();
            this.ProductNametextBox6 = new System.Windows.Forms.TextBox();
            this.suppIDextBox5 = new System.Windows.Forms.TextBox();
            this.UnitPricetextBox4 = new System.Windows.Forms.TextBox();
            this.supplierNametextBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.RemoveButton = new System.Windows.Forms.Button();
            this.AddSupplierbutton1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ordertag = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.lastHope = new System.Windows.Forms.ListBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.Quantiy = new System.Windows.Forms.Label();
            this.QuantityText = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TransactionsdataGridView2 = new System.Windows.Forms.DataGridView();
            this.searchDatetextBox1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.Addbutton3 = new System.Windows.Forms.Button();
            this.ordergroupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.inventory = new CheckMate_POS.Inventory();
            this.supplierTableAdapter = new CheckMate_POS.InventoryTableAdapters.SupplierTableAdapter();
            this.stockTableAdapter = new CheckMate_POS.InventoryTableAdapters.StockTableAdapter();
            this.stockTableAdapter1 = new CheckMate_POS.InventoryTableAdapters.StockTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.detailstab.SuspendLayout();
            this.ProductsgroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsdataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory2)).BeginInit();
            this.SuppliergroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SupplierdataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory1)).BeginInit();
            this.ordertag.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TransactionsdataGridView2)).BeginInit();
            this.ordergroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.detailstab);
            this.tabControl1.Controls.Add(this.ordertag);
            this.tabControl1.Location = new System.Drawing.Point(0, 60);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2353, 997);
            this.tabControl1.TabIndex = 0;
            // 
            // detailstab
            // 
            this.detailstab.BackColor = System.Drawing.Color.PeachPuff;
            this.detailstab.Controls.Add(this.ProductsgroupBox1);
            this.detailstab.Controls.Add(this.SuppliergroupBox1);
            this.detailstab.Controls.Add(this.SupplierIDtextBox12);
            this.detailstab.Controls.Add(this.EmailtextBox11);
            this.detailstab.Controls.Add(this.TellNumbertextBox10);
            this.detailstab.Controls.Add(this.STRAdresstextBox9);
            this.detailstab.Controls.Add(this.CitytextBox8);
            this.detailstab.Controls.Add(this.tCityCodeextBox7);
            this.detailstab.Controls.Add(this.ProductNametextBox6);
            this.detailstab.Controls.Add(this.suppIDextBox5);
            this.detailstab.Controls.Add(this.UnitPricetextBox4);
            this.detailstab.Controls.Add(this.supplierNametextBox1);
            this.detailstab.Controls.Add(this.label2);
            this.detailstab.Controls.Add(this.button2);
            this.detailstab.Controls.Add(this.button1);
            this.detailstab.Controls.Add(this.label12);
            this.detailstab.Controls.Add(this.RemoveButton);
            this.detailstab.Controls.Add(this.AddSupplierbutton1);
            this.detailstab.Controls.Add(this.label11);
            this.detailstab.Controls.Add(this.label10);
            this.detailstab.Controls.Add(this.label9);
            this.detailstab.Controls.Add(this.label8);
            this.detailstab.Controls.Add(this.label7);
            this.detailstab.Controls.Add(this.label6);
            this.detailstab.Controls.Add(this.label5);
            this.detailstab.Controls.Add(this.label4);
            this.detailstab.Controls.Add(this.label3);
            this.detailstab.Controls.Add(this.label1);
            this.detailstab.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailstab.Location = new System.Drawing.Point(4, 25);
            this.detailstab.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.detailstab.Name = "detailstab";
            this.detailstab.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.detailstab.Size = new System.Drawing.Size(2345, 968);
            this.detailstab.TabIndex = 0;
            this.detailstab.Text = "Supplier and Stock Details";
            this.detailstab.Click += new System.EventHandler(this.detailstab_Click);
            // 
            // ProductsgroupBox1
            // 
            this.ProductsgroupBox1.Controls.Add(this.label15);
            this.ProductsgroupBox1.Controls.Add(this.QuantitytextBox14);
            this.ProductsgroupBox1.Controls.Add(this.ProductsdataGridView2);
            this.ProductsgroupBox1.Controls.Add(this.SearchProdtextBox2);
            this.ProductsgroupBox1.Location = new System.Drawing.Point(747, 508);
            this.ProductsgroupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ProductsgroupBox1.Name = "ProductsgroupBox1";
            this.ProductsgroupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ProductsgroupBox1.Size = new System.Drawing.Size(1072, 417);
            this.ProductsgroupBox1.TabIndex = 30;
            this.ProductsgroupBox1.TabStop = false;
            this.ProductsgroupBox1.Text = "Products List";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(688, 71);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(187, 26);
            this.label15.TabIndex = 21;
            this.label15.Text = "Enter the Quantity";
            // 
            // QuantitytextBox14
            // 
            this.QuantitytextBox14.Location = new System.Drawing.Point(901, 68);
            this.QuantitytextBox14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QuantitytextBox14.Name = "QuantitytextBox14";
            this.QuantitytextBox14.Size = new System.Drawing.Size(83, 32);
            this.QuantitytextBox14.TabIndex = 31;
            // 
            // ProductsdataGridView2
            // 
            this.ProductsdataGridView2.AutoGenerateColumns = false;
            this.ProductsdataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductsdataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.unitPriceDataGridViewTextBoxColumn,
            this.supplierIDDataGridViewTextBoxColumn1});
            this.ProductsdataGridView2.DataSource = this.stockBindingSource;
            this.ProductsdataGridView2.Location = new System.Drawing.Point(37, 192);
            this.ProductsdataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ProductsdataGridView2.Name = "ProductsdataGridView2";
            this.ProductsdataGridView2.RowHeadersWidth = 51;
            this.ProductsdataGridView2.Size = new System.Drawing.Size(992, 186);
            this.ProductsdataGridView2.TabIndex = 20;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            this.productNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // unitPriceDataGridViewTextBoxColumn
            // 
            this.unitPriceDataGridViewTextBoxColumn.DataPropertyName = "Unit_Price";
            this.unitPriceDataGridViewTextBoxColumn.HeaderText = "Unit_Price";
            this.unitPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.unitPriceDataGridViewTextBoxColumn.Name = "unitPriceDataGridViewTextBoxColumn";
            this.unitPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // supplierIDDataGridViewTextBoxColumn1
            // 
            this.supplierIDDataGridViewTextBoxColumn1.DataPropertyName = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn1.HeaderText = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.supplierIDDataGridViewTextBoxColumn1.Name = "supplierIDDataGridViewTextBoxColumn1";
            this.supplierIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // stockBindingSource
            // 
            this.stockBindingSource.DataMember = "Stock";
            this.stockBindingSource.DataSource = this.inventory2;
            // 
            // inventory2
            // 
            this.inventory2.DataSetName = "Inventory";
            this.inventory2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SearchProdtextBox2
            // 
            this.SearchProdtextBox2.Location = new System.Drawing.Point(145, 65);
            this.SearchProdtextBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SearchProdtextBox2.Name = "SearchProdtextBox2";
            this.SearchProdtextBox2.Size = new System.Drawing.Size(475, 32);
            this.SearchProdtextBox2.TabIndex = 19;
            // 
            // SuppliergroupBox1
            // 
            this.SuppliergroupBox1.Controls.Add(this.SupplierdataGridView1);
            this.SuppliergroupBox1.Controls.Add(this.searchSuptextBox1);
            this.SuppliergroupBox1.Controls.Add(this.label18);
            this.SuppliergroupBox1.Location = new System.Drawing.Point(686, 8);
            this.SuppliergroupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SuppliergroupBox1.Name = "SuppliergroupBox1";
            this.SuppliergroupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SuppliergroupBox1.Size = new System.Drawing.Size(1210, 411);
            this.SuppliergroupBox1.TabIndex = 29;
            this.SuppliergroupBox1.TabStop = false;
            this.SuppliergroupBox1.Text = "Supplier List";
            // 
            // SupplierdataGridView1
            // 
            this.SupplierdataGridView1.AutoGenerateColumns = false;
            this.SupplierdataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SupplierdataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplierIDDataGridViewTextBoxColumn,
            this.companyNameDataGridViewTextBoxColumn,
            this.emailAddressDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn,
            this.streetAddressDataGridViewTextBoxColumn,
            this.cityNameDataGridViewTextBoxColumn,
            this.cityCodeDataGridViewTextBoxColumn});
            this.SupplierdataGridView1.DataSource = this.supplierBindingSource;
            this.SupplierdataGridView1.Location = new System.Drawing.Point(18, 100);
            this.SupplierdataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SupplierdataGridView1.Name = "SupplierdataGridView1";
            this.SupplierdataGridView1.RowHeadersWidth = 51;
            this.SupplierdataGridView1.Size = new System.Drawing.Size(1159, 270);
            this.SupplierdataGridView1.TabIndex = 19;
            this.SupplierdataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SupplierdataGridView1_CellContentClick_1);
            // 
            // supplierIDDataGridViewTextBoxColumn
            // 
            this.supplierIDDataGridViewTextBoxColumn.DataPropertyName = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn.HeaderText = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplierIDDataGridViewTextBoxColumn.Name = "supplierIDDataGridViewTextBoxColumn";
            this.supplierIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplierIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // companyNameDataGridViewTextBoxColumn
            // 
            this.companyNameDataGridViewTextBoxColumn.DataPropertyName = "Company_Name";
            this.companyNameDataGridViewTextBoxColumn.HeaderText = "Company_Name";
            this.companyNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.companyNameDataGridViewTextBoxColumn.Name = "companyNameDataGridViewTextBoxColumn";
            this.companyNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailAddressDataGridViewTextBoxColumn
            // 
            this.emailAddressDataGridViewTextBoxColumn.DataPropertyName = "Email_Address";
            this.emailAddressDataGridViewTextBoxColumn.HeaderText = "Email_Address";
            this.emailAddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailAddressDataGridViewTextBoxColumn.Name = "emailAddressDataGridViewTextBoxColumn";
            this.emailAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "Phone_Number";
            this.phoneNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            this.phoneNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // streetAddressDataGridViewTextBoxColumn
            // 
            this.streetAddressDataGridViewTextBoxColumn.DataPropertyName = "Street_Address";
            this.streetAddressDataGridViewTextBoxColumn.HeaderText = "Street_Address";
            this.streetAddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.streetAddressDataGridViewTextBoxColumn.Name = "streetAddressDataGridViewTextBoxColumn";
            this.streetAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // cityNameDataGridViewTextBoxColumn
            // 
            this.cityNameDataGridViewTextBoxColumn.DataPropertyName = "City_Name";
            this.cityNameDataGridViewTextBoxColumn.HeaderText = "City_Name";
            this.cityNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cityNameDataGridViewTextBoxColumn.Name = "cityNameDataGridViewTextBoxColumn";
            this.cityNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // cityCodeDataGridViewTextBoxColumn
            // 
            this.cityCodeDataGridViewTextBoxColumn.DataPropertyName = "City_Code";
            this.cityCodeDataGridViewTextBoxColumn.HeaderText = "City_Code";
            this.cityCodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cityCodeDataGridViewTextBoxColumn.Name = "cityCodeDataGridViewTextBoxColumn";
            this.cityCodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.inventory1;
            // 
            // inventory1
            // 
            this.inventory1.DataSetName = "Inventory";
            this.inventory1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // searchSuptextBox1
            // 
            this.searchSuptextBox1.Location = new System.Drawing.Point(375, 53);
            this.searchSuptextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.searchSuptextBox1.Name = "searchSuptextBox1";
            this.searchSuptextBox1.Size = new System.Drawing.Size(475, 32);
            this.searchSuptextBox1.TabIndex = 18;
            this.searchSuptextBox1.TextChanged += new System.EventHandler(this.searchSuptextBox1_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 57);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(261, 26);
            this.label18.TabIndex = 5;
            this.label18.Text = "Search Supplier by Name";
            // 
            // SupplierIDtextBox12
            // 
            this.SupplierIDtextBox12.Location = new System.Drawing.Point(325, 139);
            this.SupplierIDtextBox12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SupplierIDtextBox12.Name = "SupplierIDtextBox12";
            this.SupplierIDtextBox12.Size = new System.Drawing.Size(319, 32);
            this.SupplierIDtextBox12.TabIndex = 28;
            this.SupplierIDtextBox12.TextChanged += new System.EventHandler(this.SupplierIDtextBox12_TextChanged);
            // 
            // EmailtextBox11
            // 
            this.EmailtextBox11.Location = new System.Drawing.Point(325, 182);
            this.EmailtextBox11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EmailtextBox11.Name = "EmailtextBox11";
            this.EmailtextBox11.Size = new System.Drawing.Size(319, 32);
            this.EmailtextBox11.TabIndex = 27;
            this.EmailtextBox11.TextChanged += new System.EventHandler(this.EmailtextBox11_TextChanged);
            // 
            // TellNumbertextBox10
            // 
            this.TellNumbertextBox10.Location = new System.Drawing.Point(325, 224);
            this.TellNumbertextBox10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TellNumbertextBox10.Name = "TellNumbertextBox10";
            this.TellNumbertextBox10.Size = new System.Drawing.Size(319, 32);
            this.TellNumbertextBox10.TabIndex = 26;
            this.TellNumbertextBox10.TextChanged += new System.EventHandler(this.TellNumbertextBox10_TextChanged);
            // 
            // STRAdresstextBox9
            // 
            this.STRAdresstextBox9.Location = new System.Drawing.Point(325, 265);
            this.STRAdresstextBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.STRAdresstextBox9.Name = "STRAdresstextBox9";
            this.STRAdresstextBox9.Size = new System.Drawing.Size(319, 32);
            this.STRAdresstextBox9.TabIndex = 25;
            this.STRAdresstextBox9.TextChanged += new System.EventHandler(this.STRAdresstextBox9_TextChanged);
            // 
            // CitytextBox8
            // 
            this.CitytextBox8.Location = new System.Drawing.Point(325, 305);
            this.CitytextBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CitytextBox8.Name = "CitytextBox8";
            this.CitytextBox8.Size = new System.Drawing.Size(319, 32);
            this.CitytextBox8.TabIndex = 24;
            this.CitytextBox8.TextChanged += new System.EventHandler(this.CitytextBox8_TextChanged);
            // 
            // tCityCodeextBox7
            // 
            this.tCityCodeextBox7.Location = new System.Drawing.Point(325, 346);
            this.tCityCodeextBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tCityCodeextBox7.Name = "tCityCodeextBox7";
            this.tCityCodeextBox7.Size = new System.Drawing.Size(319, 32);
            this.tCityCodeextBox7.TabIndex = 23;
            this.tCityCodeextBox7.TextChanged += new System.EventHandler(this.tCityCodeextBox7_TextChanged);
            // 
            // ProductNametextBox6
            // 
            this.ProductNametextBox6.Location = new System.Drawing.Point(325, 655);
            this.ProductNametextBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ProductNametextBox6.Name = "ProductNametextBox6";
            this.ProductNametextBox6.Size = new System.Drawing.Size(319, 32);
            this.ProductNametextBox6.TabIndex = 22;
            this.ProductNametextBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // suppIDextBox5
            // 
            this.suppIDextBox5.Location = new System.Drawing.Point(325, 700);
            this.suppIDextBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.suppIDextBox5.Name = "suppIDextBox5";
            this.suppIDextBox5.Size = new System.Drawing.Size(319, 32);
            this.suppIDextBox5.TabIndex = 21;
            // 
            // UnitPricetextBox4
            // 
            this.UnitPricetextBox4.Location = new System.Drawing.Point(325, 747);
            this.UnitPricetextBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.UnitPricetextBox4.Name = "UnitPricetextBox4";
            this.UnitPricetextBox4.Size = new System.Drawing.Size(319, 32);
            this.UnitPricetextBox4.TabIndex = 20;
            this.UnitPricetextBox4.TextChanged += new System.EventHandler(this.UnitPricetextBox4_TextChanged);
            // 
            // supplierNametextBox1
            // 
            this.supplierNametextBox1.Location = new System.Drawing.Point(325, 95);
            this.supplierNametextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.supplierNametextBox1.Name = "supplierNametextBox1";
            this.supplierNametextBox1.Size = new System.Drawing.Size(319, 32);
            this.supplierNametextBox1.TabIndex = 17;
            this.supplierNametextBox1.TextChanged += new System.EventHandler(this.supplierNametextBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 564);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(325, 48);
            this.label2.TabIndex = 16;
            this.label2.Text = "Products Details";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(276, 866);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 41);
            this.button2.TabIndex = 15;
            this.button2.Text = "Remove";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Peru;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(32, 866);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 41);
            this.button1.TabIndex = 14;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(27, 25);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(314, 48);
            this.label12.TabIndex = 13;
            this.label12.Text = "Supplier Details";
            // 
            // RemoveButton
            // 
            this.RemoveButton.BackColor = System.Drawing.Color.Red;
            this.RemoveButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RemoveButton.Location = new System.Drawing.Point(276, 421);
            this.RemoveButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.RemoveButton.Name = "RemoveButton";
            this.RemoveButton.Size = new System.Drawing.Size(112, 41);
            this.RemoveButton.TabIndex = 12;
            this.RemoveButton.Text = "Remove";
            this.RemoveButton.UseVisualStyleBackColor = false;
            this.RemoveButton.Click += new System.EventHandler(this.RemoveButton_Click);
            // 
            // AddSupplierbutton1
            // 
            this.AddSupplierbutton1.BackColor = System.Drawing.Color.Peru;
            this.AddSupplierbutton1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddSupplierbutton1.Location = new System.Drawing.Point(32, 421);
            this.AddSupplierbutton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddSupplierbutton1.Name = "AddSupplierbutton1";
            this.AddSupplierbutton1.Size = new System.Drawing.Size(112, 41);
            this.AddSupplierbutton1.TabIndex = 11;
            this.AddSupplierbutton1.Text = "Add";
            this.AddSupplierbutton1.UseVisualStyleBackColor = false;
            this.AddSupplierbutton1.Click += new System.EventHandler(this.AddSupplierbutton1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(31, 145);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "Supplier ID";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 188);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 26);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 230);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 26);
            this.label9.TabIndex = 8;
            this.label9.Text = "Tel Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 271);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(144, 26);
            this.label8.TabIndex = 7;
            this.label8.Text = "Street Adress";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 311);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 26);
            this.label7.TabIndex = 6;
            this.label7.Text = "City";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 352);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "City Code";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 658);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "Product Name";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 706);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Supplier ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 753);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 26);
            this.label3.TabIndex = 2;
            this.label3.Text = "Unit Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 101);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // ordertag
            // 
            this.ordertag.BackColor = System.Drawing.Color.PeachPuff;
            this.ordertag.Controls.Add(this.button3);
            this.ordertag.Controls.Add(this.lastHope);
            this.ordertag.Controls.Add(this.totalTextBox);
            this.ordertag.Controls.Add(this.Quantiy);
            this.ordertag.Controls.Add(this.QuantityText);
            this.ordertag.Controls.Add(this.groupBox1);
            this.ordertag.Controls.Add(this.Addbutton3);
            this.ordertag.Controls.Add(this.ordergroupBox1);
            this.ordertag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ordertag.Location = new System.Drawing.Point(4, 25);
            this.ordertag.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ordertag.Name = "ordertag";
            this.ordertag.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ordertag.Size = new System.Drawing.Size(2345, 968);
            this.ordertag.TabIndex = 1;
            this.ordertag.Text = "      Order    ";
            this.ordertag.Click += new System.EventHandler(this.ordertag_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Peru;
            this.button3.Location = new System.Drawing.Point(383, 235);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(201, 57);
            this.button3.TabIndex = 21;
            this.button3.Text = "Send Order";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lastHope
            // 
            this.lastHope.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lastHope.FormattingEnabled = true;
            this.lastHope.ItemHeight = 26;
            this.lastHope.Location = new System.Drawing.Point(1412, 82);
            this.lastHope.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lastHope.Name = "lastHope";
            this.lastHope.Size = new System.Drawing.Size(524, 446);
            this.lastHope.TabIndex = 20;
            // 
            // totalTextBox
            // 
            this.totalTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.totalTextBox.Location = new System.Drawing.Point(8, 31);
            this.totalTextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(132, 32);
            this.totalTextBox.TabIndex = 18;
            this.totalTextBox.TextChanged += new System.EventHandler(this.totalTextBox_TextChanged);
            // 
            // Quantiy
            // 
            this.Quantiy.AutoSize = true;
            this.Quantiy.Location = new System.Drawing.Point(377, 86);
            this.Quantiy.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Quantiy.Name = "Quantiy";
            this.Quantiy.Size = new System.Drawing.Size(181, 26);
            this.Quantiy.TabIndex = 17;
            this.Quantiy.Text = "Enter theQuantity";
            // 
            // QuantityText
            // 
            this.QuantityText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.QuantityText.Location = new System.Drawing.Point(585, 82);
            this.QuantityText.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.QuantityText.Name = "QuantityText";
            this.QuantityText.Size = new System.Drawing.Size(49, 32);
            this.QuantityText.TabIndex = 16;
            this.QuantityText.Text = "1";
            this.QuantityText.TextChanged += new System.EventHandler(this.QuantityText_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TransactionsdataGridView2);
            this.groupBox1.Controls.Add(this.searchDatetextBox1);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Location = new System.Drawing.Point(707, 561);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(1393, 396);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Order Transactions";
            // 
            // TransactionsdataGridView2
            // 
            this.TransactionsdataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TransactionsdataGridView2.Location = new System.Drawing.Point(8, 97);
            this.TransactionsdataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TransactionsdataGridView2.Name = "TransactionsdataGridView2";
            this.TransactionsdataGridView2.RowHeadersWidth = 51;
            this.TransactionsdataGridView2.Size = new System.Drawing.Size(1363, 299);
            this.TransactionsdataGridView2.TabIndex = 12;
            // 
            // searchDatetextBox1
            // 
            this.searchDatetextBox1.Location = new System.Drawing.Point(364, 47);
            this.searchDatetextBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.searchDatetextBox1.Name = "searchDatetextBox1";
            this.searchDatetextBox1.Size = new System.Drawing.Size(437, 32);
            this.searchDatetextBox1.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(24, 47);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(287, 26);
            this.label20.TabIndex = 1;
            this.label20.Text = "Seaerth Transaction by Date";
            // 
            // Addbutton3
            // 
            this.Addbutton3.BackColor = System.Drawing.Color.Peru;
            this.Addbutton3.Location = new System.Drawing.Point(383, 144);
            this.Addbutton3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Addbutton3.Name = "Addbutton3";
            this.Addbutton3.Size = new System.Drawing.Size(201, 57);
            this.Addbutton3.TabIndex = 14;
            this.Addbutton3.Text = "Add products>>";
            this.Addbutton3.UseVisualStyleBackColor = false;
            this.Addbutton3.Click += new System.EventHandler(this.Addbutton3_Click);
            // 
            // ordergroupBox1
            // 
            this.ordergroupBox1.Controls.Add(this.dataGridView1);
            this.ordergroupBox1.Location = new System.Drawing.Point(707, 48);
            this.ordergroupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ordergroupBox1.Name = "ordergroupBox1";
            this.ordergroupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ordergroupBox1.Size = new System.Drawing.Size(613, 481);
            this.ordergroupBox1.TabIndex = 13;
            this.ordergroupBox1.TabStop = false;
            this.ordergroupBox1.Text = "Order List";
            this.ordergroupBox1.Enter += new System.EventHandler(this.ordergroupBox1_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn1,
            this.productNameDataGridViewTextBoxColumn1,
            this.unitPriceDataGridViewTextBoxColumn1,
            this.supplierIDDataGridViewTextBoxColumn2});
            this.dataGridView1.DataSource = this.stockBindingSource1;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(4, 29);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(605, 448);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // productNameDataGridViewTextBoxColumn1
            // 
            this.productNameDataGridViewTextBoxColumn1.DataPropertyName = "Product_Name";
            this.productNameDataGridViewTextBoxColumn1.HeaderText = "Product_Name";
            this.productNameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.productNameDataGridViewTextBoxColumn1.Name = "productNameDataGridViewTextBoxColumn1";
            this.productNameDataGridViewTextBoxColumn1.Width = 125;
            // 
            // unitPriceDataGridViewTextBoxColumn1
            // 
            this.unitPriceDataGridViewTextBoxColumn1.DataPropertyName = "Unit_Price";
            this.unitPriceDataGridViewTextBoxColumn1.HeaderText = "Unit_Price";
            this.unitPriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.unitPriceDataGridViewTextBoxColumn1.Name = "unitPriceDataGridViewTextBoxColumn1";
            this.unitPriceDataGridViewTextBoxColumn1.Width = 125;
            // 
            // supplierIDDataGridViewTextBoxColumn2
            // 
            this.supplierIDDataGridViewTextBoxColumn2.DataPropertyName = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn2.HeaderText = "Supplier_ID";
            this.supplierIDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.supplierIDDataGridViewTextBoxColumn2.Name = "supplierIDDataGridViewTextBoxColumn2";
            this.supplierIDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // stockBindingSource1
            // 
            this.stockBindingSource1.DataMember = "Stock";
            this.stockBindingSource1.DataSource = this.inventory2;
            // 
            // inventory
            // 
            this.inventory.DataSetName = "Inventory";
            this.inventory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // stockTableAdapter
            // 
            this.stockTableAdapter.ClearBeforeFill = true;
            // 
            // stockTableAdapter1
            // 
            this.stockTableAdapter1.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2233, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // SUPPLIER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1924, 1055);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SUPPLIER";
            this.Text = "SUPPLIER";
            this.Load += new System.EventHandler(this.SUPPLIER_Load);
            this.tabControl1.ResumeLayout(false);
            this.detailstab.ResumeLayout(false);
            this.detailstab.PerformLayout();
            this.ProductsgroupBox1.ResumeLayout(false);
            this.ProductsgroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsdataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory2)).EndInit();
            this.SuppliergroupBox1.ResumeLayout(false);
            this.SuppliergroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SupplierdataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory1)).EndInit();
            this.ordertag.ResumeLayout(false);
            this.ordertag.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TransactionsdataGridView2)).EndInit();
            this.ordergroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage detailstab;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button RemoveButton;
        private System.Windows.Forms.Button AddSupplierbutton1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SupplierIDtextBox12;
        private System.Windows.Forms.TextBox EmailtextBox11;
        private System.Windows.Forms.TextBox TellNumbertextBox10;
        private System.Windows.Forms.TextBox STRAdresstextBox9;
        private System.Windows.Forms.TextBox CitytextBox8;
        private System.Windows.Forms.TextBox tCityCodeextBox7;
        private System.Windows.Forms.TextBox ProductNametextBox6;
        private System.Windows.Forms.TextBox suppIDextBox5;
        private System.Windows.Forms.TextBox UnitPricetextBox4;
        private System.Windows.Forms.TextBox supplierNametextBox1;
        private System.Windows.Forms.GroupBox ProductsgroupBox1;
        private System.Windows.Forms.DataGridView ProductsdataGridView2;
        private System.Windows.Forms.TextBox SearchProdtextBox2;
        private System.Windows.Forms.GroupBox SuppliergroupBox1;
        private System.Windows.Forms.TextBox searchSuptextBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Inventory inventory;
        private System.Windows.Forms.DataGridView SupplierdataGridView1;
        private Inventory inventory1;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private InventoryTableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn streetAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityCodeDataGridViewTextBoxColumn;
        private Inventory inventory2;
        private InventoryTableAdapters.StockTableAdapter stockTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource stockBindingSource;
        private System.Windows.Forms.TabPage ordertag;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView TransactionsdataGridView2;
        private System.Windows.Forms.TextBox searchDatetextBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox ordergroupBox1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox QuantitytextBox14;
        private System.Windows.Forms.DataGridView dataGridView1;
        private InventoryTableAdapters.StockTableAdapter stockTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource stockBindingSource1;
        private System.Windows.Forms.Button Addbutton3;
        private System.Windows.Forms.TextBox QuantityText;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Label Quantiy;
        private System.Windows.Forms.ListBox lastHope;
        private System.Windows.Forms.Button button3;
    }
}