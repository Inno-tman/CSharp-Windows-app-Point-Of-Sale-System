﻿
namespace CheckMate_POS
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.payBox = new System.Windows.Forms.TextBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.changeBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.products = new CheckMate_POS.Products();
            this.removeButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.QuantityText = new System.Windows.Forms.TextBox();
            this.productTableAdapter = new CheckMate_POS.ProductsTableAdapters.ProductTableAdapter();
            this.slip = new System.Windows.Forms.ListBox();
            this.label9 = new System.Windows.Forms.Label();
            this.DiscounttextBox = new System.Windows.Forms.TextBox();
            this.tableAdapterManager1 = new CheckMate_POS.ActorsTableAdapters.TableAdapterManager();
            this.salesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salesData = new CheckMate_POS.SalesData();
            this.salesDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salesTableAdapter = new CheckMate_POS.SalesDataTableAdapters.SalesTableAdapter();
            this.saleIncomeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saleIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.test = new System.Windows.Forms.TextBox();
            this.saleeeData = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.saless = new CheckMate_POS.Saless();
            this.productsOrderTableAdapter = new CheckMate_POS.SalessTableAdapters.ProductsOrderTableAdapter();
            this.tableAdapterManager = new CheckMate_POS.SalessTableAdapters.TableAdapterManager();
            this.orderTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.oRDERIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOofItemsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.order1 = new CheckMate_POS.Order();
            this.orderTable1TableAdapter = new CheckMate_POS.OrderTableAdapters.OrderTable1TableAdapter();
            this.tableAdapterManager2 = new CheckMate_POS.OrderTableAdapters.TableAdapterManager();
            this.orderTable5BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productsOrder5BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.orderIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTable6BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.order6 = new CheckMate_POS.Order6();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderIDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsOrder6BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderTable6TableAdapter = new CheckMate_POS.Order6TableAdapters.OrderTable6TableAdapter();
            this.tableAdapterManager3 = new CheckMate_POS.Order6TableAdapters.TableAdapterManager();
            this.productsOrder6TableAdapter = new CheckMate_POS.Order6TableAdapters.ProductsOrder6TableAdapter();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderIDDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsOrder7BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.order7 = new CheckMate_POS.Order7();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.orderIDDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTotalDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTable7BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderTable7TableAdapter = new CheckMate_POS.Order7TableAdapters.OrderTable7TableAdapter();
            this.tableAdapterManager4 = new CheckMate_POS.Order7TableAdapters.TableAdapterManager();
            this.productsOrder7TableAdapter = new CheckMate_POS.Order7TableAdapters.ProductsOrder7TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.products)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleeeData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saless)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.order1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable5BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder5BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable6BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.order6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder6BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder7BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.order7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable7BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1742, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PeachPuff;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(295, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Search by Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(427, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(224, 30);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // payBox
            // 
            this.payBox.Location = new System.Drawing.Point(1392, 136);
            this.payBox.Name = "payBox";
            this.payBox.Size = new System.Drawing.Size(52, 20);
            this.payBox.TabIndex = 6;
            this.payBox.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // totalTextBox
            // 
            this.totalTextBox.Location = new System.Drawing.Point(1392, 91);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(52, 20);
            this.totalTextBox.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Peru;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1298, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 60);
            this.button1.TabIndex = 8;
            this.button1.Text = "Process Payment";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Peru;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(829, 636);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 35);
            this.button2.TabIndex = 9;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1298, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Total";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1302, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "Paid";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // changeBox
            // 
            this.changeBox.Location = new System.Drawing.Point(1392, 180);
            this.changeBox.Name = "changeBox";
            this.changeBox.Size = new System.Drawing.Size(52, 20);
            this.changeBox.TabIndex = 12;
            this.changeBox.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1294, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 25);
            this.label4.TabIndex = 13;
            this.label4.Text = "Change";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Peru;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(12, 238);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(143, 35);
            this.button3.TabIndex = 14;
            this.button3.Text = "Add Item ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1439, 56);
            this.panel1.TabIndex = 15;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1262, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(86, 47);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.PeachPuff;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(784, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(272, 31);
            this.label6.TabIndex = 10;
            this.label6.Text = "CHECKMATE MENU";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "All",
            "Bakery",
            "Desserts",
            "Fruits",
            "Beverages"});
            this.comboBox1.Location = new System.Drawing.Point(146, 50);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(123, 33);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.PeachPuff;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(18, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "Select Category";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(161, 85);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(662, 534);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Items List";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.Quantity});
            this.dataGridView1.DataSource = this.productBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(22, 94);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(629, 414);
            this.dataGridView1.TabIndex = 0;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            this.productIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.productIDDataGridViewTextBoxColumn.Width = 134;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.Width = 117;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 134;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 125;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.MinimumWidth = 6;
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 125;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.products;
            // 
            // products
            // 
            this.products.DataSetName = "Products";
            this.products.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // removeButton
            // 
            this.removeButton.BackColor = System.Drawing.Color.Peru;
            this.removeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeButton.Location = new System.Drawing.Point(1144, 635);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(143, 35);
            this.removeButton.TabIndex = 17;
            this.removeButton.Text = "Remove Item";
            this.removeButton.UseVisualStyleBackColor = false;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.PeachPuff;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(7, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 25);
            this.label7.TabIndex = 18;
            this.label7.Text = "Quantity";
            // 
            // QuantityText
            // 
            this.QuantityText.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityText.Location = new System.Drawing.Point(98, 187);
            this.QuantityText.Multiline = true;
            this.QuantityText.Name = "QuantityText";
            this.QuantityText.Size = new System.Drawing.Size(57, 30);
            this.QuantityText.TabIndex = 19;
            this.QuantityText.Text = "1";
            this.QuantityText.TextChanged += new System.EventHandler(this.QuantityText_TextChanged);
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // slip
            // 
            this.slip.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slip.FormattingEnabled = true;
            this.slip.ItemHeight = 18;
            this.slip.Location = new System.Drawing.Point(829, 91);
            this.slip.Name = "slip";
            this.slip.Size = new System.Drawing.Size(460, 526);
            this.slip.TabIndex = 20;
            this.slip.SelectedIndexChanged += new System.EventHandler(this.slip_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1294, 214);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 25);
            this.label9.TabIndex = 23;
            this.label9.Text = "Discount";
            // 
            // DiscounttextBox
            // 
            this.DiscounttextBox.Location = new System.Drawing.Point(1392, 220);
            this.DiscounttextBox.Name = "DiscounttextBox";
            this.DiscounttextBox.Size = new System.Drawing.Size(52, 20);
            this.DiscounttextBox.TabIndex = 24;
            this.DiscounttextBox.TextChanged += new System.EventHandler(this.DiscounttextBox_TextChanged);
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.CustomerTableAdapter = null;
            this.tableAdapterManager1.EmployeeTableAdapter = null;
            this.tableAdapterManager1.SupplierTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = CheckMate_POS.ActorsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // salesBindingSource
            // 
            this.salesBindingSource.DataMember = "Sales";
            this.salesBindingSource.DataSource = this.salesData;
            // 
            // salesData
            // 
            this.salesData.DataSetName = "SalesData";
            this.salesData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salesDataBindingSource
            // 
            this.salesDataBindingSource.DataSource = this.salesData;
            this.salesDataBindingSource.Position = 0;
            // 
            // salesTableAdapter
            // 
            this.salesTableAdapter.ClearBeforeFill = true;
            // 
            // saleIncomeDataGridViewTextBoxColumn
            // 
            this.saleIncomeDataGridViewTextBoxColumn.DataPropertyName = "Sale_Income";
            this.saleIncomeDataGridViewTextBoxColumn.HeaderText = "Sale_Income";
            this.saleIncomeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.saleIncomeDataGridViewTextBoxColumn.Name = "saleIncomeDataGridViewTextBoxColumn";
            this.saleIncomeDataGridViewTextBoxColumn.Width = 125;
            // 
            // saleDateDataGridViewTextBoxColumn
            // 
            this.saleDateDataGridViewTextBoxColumn.DataPropertyName = "Sale_Date";
            this.saleDateDataGridViewTextBoxColumn.HeaderText = "Sale_Date";
            this.saleDateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.saleDateDataGridViewTextBoxColumn.Name = "saleDateDataGridViewTextBoxColumn";
            this.saleDateDataGridViewTextBoxColumn.Width = 125;
            // 
            // saleIDDataGridViewTextBoxColumn
            // 
            this.saleIDDataGridViewTextBoxColumn.DataPropertyName = "Sale_ID";
            this.saleIDDataGridViewTextBoxColumn.HeaderText = "Sale_ID";
            this.saleIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.saleIDDataGridViewTextBoxColumn.Name = "saleIDDataGridViewTextBoxColumn";
            this.saleIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.saleIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.saleIDDataGridViewTextBoxColumn,
            this.saleDateDataGridViewTextBoxColumn,
            this.saleIncomeDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.salesBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(402, 648);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(44, 36);
            this.dataGridView2.TabIndex = 25;
            this.dataGridView2.Visible = false;
            // 
            // test
            // 
            this.test.Location = new System.Drawing.Point(641, 690);
            this.test.Name = "test";
            this.test.Size = new System.Drawing.Size(98, 20);
            this.test.TabIndex = 26;
            // 
            // saleeeData
            // 
            this.saleeeData.AutoGenerateColumns = false;
            this.saleeeData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.saleeeData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn1,
            this.orderIDDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.unitPriceDataGridViewTextBoxColumn,
            this.subTotalDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn});
            this.saleeeData.DataSource = this.productsOrderBindingSource;
            this.saleeeData.Location = new System.Drawing.Point(588, 636);
            this.saleeeData.Name = "saleeeData";
            this.saleeeData.RowHeadersWidth = 51;
            this.saleeeData.Size = new System.Drawing.Size(44, 35);
            this.saleeeData.TabIndex = 27;
            this.saleeeData.Visible = false;
            // 
            // productIDDataGridViewTextBoxColumn1
            // 
            this.productIDDataGridViewTextBoxColumn1.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn1.Name = "productIDDataGridViewTextBoxColumn1";
            this.productIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // orderIDDataGridViewTextBoxColumn
            // 
            this.orderIDDataGridViewTextBoxColumn.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.orderIDDataGridViewTextBoxColumn.Name = "orderIDDataGridViewTextBoxColumn";
            this.orderIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 125;
            // 
            // unitPriceDataGridViewTextBoxColumn
            // 
            this.unitPriceDataGridViewTextBoxColumn.DataPropertyName = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn.HeaderText = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.unitPriceDataGridViewTextBoxColumn.Name = "unitPriceDataGridViewTextBoxColumn";
            this.unitPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // subTotalDataGridViewTextBoxColumn
            // 
            this.subTotalDataGridViewTextBoxColumn.DataPropertyName = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn.HeaderText = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.subTotalDataGridViewTextBoxColumn.Name = "subTotalDataGridViewTextBoxColumn";
            this.subTotalDataGridViewTextBoxColumn.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 125;
            // 
            // productsOrderBindingSource
            // 
            this.productsOrderBindingSource.DataMember = "ProductsOrder";
            this.productsOrderBindingSource.DataSource = this.saless;
            // 
            // saless
            // 
            this.saless.DataSetName = "Saless";
            this.saless.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productsOrderTableAdapter
            // 
            this.productsOrderTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ProductsOrderTableAdapter = this.productsOrderTableAdapter;
            this.tableAdapterManager.UpdateOrder = CheckMate_POS.SalessTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // orderTableBindingSource
            // 
            this.orderTableBindingSource.DataMember = "OrderTable";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.oRDERIDDataGridViewTextBoxColumn1,
            this.dateDataGridViewTextBoxColumn1,
            this.nOofItemsDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn1,
            this.subTotalDataGridViewTextBoxColumn1,
            this.employeeIDDataGridViewTextBoxColumn,
            this.employeeNameDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.orderTable1BindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(768, 636);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(43, 35);
            this.dataGridView3.TabIndex = 17;
            this.dataGridView3.Visible = false;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick_1);
            // 
            // oRDERIDDataGridViewTextBoxColumn1
            // 
            this.oRDERIDDataGridViewTextBoxColumn1.DataPropertyName = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn1.HeaderText = "ORDER_ID";
            this.oRDERIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.oRDERIDDataGridViewTextBoxColumn1.Name = "oRDERIDDataGridViewTextBoxColumn1";
            this.oRDERIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn1
            // 
            this.dateDataGridViewTextBoxColumn1.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn1.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn1.Name = "dateDataGridViewTextBoxColumn1";
            this.dateDataGridViewTextBoxColumn1.Width = 125;
            // 
            // nOofItemsDataGridViewTextBoxColumn
            // 
            this.nOofItemsDataGridViewTextBoxColumn.DataPropertyName = "NO_of_Items";
            this.nOofItemsDataGridViewTextBoxColumn.HeaderText = "NO_of_Items";
            this.nOofItemsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nOofItemsDataGridViewTextBoxColumn.Name = "nOofItemsDataGridViewTextBoxColumn";
            this.nOofItemsDataGridViewTextBoxColumn.Width = 125;
            // 
            // priceDataGridViewTextBoxColumn1
            // 
            this.priceDataGridViewTextBoxColumn1.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn1.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.priceDataGridViewTextBoxColumn1.Name = "priceDataGridViewTextBoxColumn1";
            this.priceDataGridViewTextBoxColumn1.Width = 125;
            // 
            // subTotalDataGridViewTextBoxColumn1
            // 
            this.subTotalDataGridViewTextBoxColumn1.DataPropertyName = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn1.HeaderText = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.subTotalDataGridViewTextBoxColumn1.Name = "subTotalDataGridViewTextBoxColumn1";
            this.subTotalDataGridViewTextBoxColumn1.Width = 125;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeNameDataGridViewTextBoxColumn
            // 
            this.employeeNameDataGridViewTextBoxColumn.DataPropertyName = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn.HeaderText = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeNameDataGridViewTextBoxColumn.Name = "employeeNameDataGridViewTextBoxColumn";
            this.employeeNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // orderTable1BindingSource
            // 
            this.orderTable1BindingSource.DataMember = "OrderTable1";
            this.orderTable1BindingSource.DataSource = this.order1;
            // 
            // order1
            // 
            this.order1.DataSetName = "Order";
            this.order1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderTable1TableAdapter
            // 
            this.orderTable1TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.OrderTable1TableAdapter = this.orderTable1TableAdapter;
            this.tableAdapterManager2.UpdateOrder = CheckMate_POS.OrderTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn2,
            this.dateDataGridViewTextBoxColumn2,
            this.employeeIDDataGridViewTextBoxColumn1,
            this.employeeNameDataGridViewTextBoxColumn1,
            this.orderTotalDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.orderTable6BindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(662, 649);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(54, 34);
            this.dataGridView4.TabIndex = 28;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick_1);
            // 
            // orderIDDataGridViewTextBoxColumn2
            // 
            this.orderIDDataGridViewTextBoxColumn2.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn2.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.orderIDDataGridViewTextBoxColumn2.Name = "orderIDDataGridViewTextBoxColumn2";
            this.orderIDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn2
            // 
            this.dateDataGridViewTextBoxColumn2.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn2.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn2.Name = "dateDataGridViewTextBoxColumn2";
            this.dateDataGridViewTextBoxColumn2.Width = 125;
            // 
            // employeeIDDataGridViewTextBoxColumn1
            // 
            this.employeeIDDataGridViewTextBoxColumn1.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn1.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn1.Name = "employeeIDDataGridViewTextBoxColumn1";
            this.employeeIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // employeeNameDataGridViewTextBoxColumn1
            // 
            this.employeeNameDataGridViewTextBoxColumn1.DataPropertyName = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn1.HeaderText = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.employeeNameDataGridViewTextBoxColumn1.Name = "employeeNameDataGridViewTextBoxColumn1";
            this.employeeNameDataGridViewTextBoxColumn1.Width = 125;
            // 
            // orderTotalDataGridViewTextBoxColumn
            // 
            this.orderTotalDataGridViewTextBoxColumn.DataPropertyName = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn.HeaderText = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.orderTotalDataGridViewTextBoxColumn.Name = "orderTotalDataGridViewTextBoxColumn";
            this.orderTotalDataGridViewTextBoxColumn.Width = 125;
            // 
            // orderTable6BindingSource
            // 
            this.orderTable6BindingSource.DataMember = "OrderTable6";
            this.orderTable6BindingSource.DataSource = this.order6;
            // 
            // order6
            // 
            this.order6.DataSetName = "Order6";
            this.order6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn2,
            this.orderIDDataGridViewTextBoxColumn3,
            this.quantityDataGridViewTextBoxColumn1,
            this.unitPriceDataGridViewTextBoxColumn1,
            this.subTotalDataGridViewTextBoxColumn2,
            this.dateDataGridViewTextBoxColumn3});
            this.dataGridView5.DataSource = this.productsOrder6BindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(491, 636);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.Size = new System.Drawing.Size(45, 44);
            this.dataGridView5.TabIndex = 29;
            // 
            // productIDDataGridViewTextBoxColumn2
            // 
            this.productIDDataGridViewTextBoxColumn2.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn2.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn2.Name = "productIDDataGridViewTextBoxColumn2";
            this.productIDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // orderIDDataGridViewTextBoxColumn3
            // 
            this.orderIDDataGridViewTextBoxColumn3.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn3.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.orderIDDataGridViewTextBoxColumn3.Name = "orderIDDataGridViewTextBoxColumn3";
            this.orderIDDataGridViewTextBoxColumn3.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn1
            // 
            this.quantityDataGridViewTextBoxColumn1.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn1.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn1.Name = "quantityDataGridViewTextBoxColumn1";
            this.quantityDataGridViewTextBoxColumn1.Width = 125;
            // 
            // unitPriceDataGridViewTextBoxColumn1
            // 
            this.unitPriceDataGridViewTextBoxColumn1.DataPropertyName = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn1.HeaderText = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.unitPriceDataGridViewTextBoxColumn1.Name = "unitPriceDataGridViewTextBoxColumn1";
            this.unitPriceDataGridViewTextBoxColumn1.Width = 125;
            // 
            // subTotalDataGridViewTextBoxColumn2
            // 
            this.subTotalDataGridViewTextBoxColumn2.DataPropertyName = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn2.HeaderText = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.subTotalDataGridViewTextBoxColumn2.Name = "subTotalDataGridViewTextBoxColumn2";
            this.subTotalDataGridViewTextBoxColumn2.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn3
            // 
            this.dateDataGridViewTextBoxColumn3.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn3.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn3.Name = "dateDataGridViewTextBoxColumn3";
            this.dateDataGridViewTextBoxColumn3.Width = 125;
            // 
            // productsOrder6BindingSource
            // 
            this.productsOrder6BindingSource.DataMember = "ProductsOrder6";
            this.productsOrder6BindingSource.DataSource = this.order6;
            // 
            // orderTable6TableAdapter
            // 
            this.orderTable6TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager3
            // 
            this.tableAdapterManager3.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager3.OrderTable6TableAdapter = this.orderTable6TableAdapter;
            this.tableAdapterManager3.ProductsOrder6TableAdapter = this.productsOrder6TableAdapter;
            this.tableAdapterManager3.UpdateOrder = CheckMate_POS.Order6TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // productsOrder6TableAdapter
            // 
            this.productsOrder6TableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn3,
            this.orderIDDataGridViewTextBoxColumn5,
            this.quantityDataGridViewTextBoxColumn2,
            this.unitPriceDataGridViewTextBoxColumn2,
            this.subTotalDataGridViewTextBoxColumn3,
            this.dateDataGridViewTextBoxColumn5});
            this.dataGridView6.DataSource = this.productsOrder7BindingSource;
            this.dataGridView6.Location = new System.Drawing.Point(829, 682);
            this.dataGridView6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.RowTemplate.Height = 24;
            this.dataGridView6.Size = new System.Drawing.Size(133, 67);
            this.dataGridView6.TabIndex = 30;
            // 
            // productIDDataGridViewTextBoxColumn3
            // 
            this.productIDDataGridViewTextBoxColumn3.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn3.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.productIDDataGridViewTextBoxColumn3.Name = "productIDDataGridViewTextBoxColumn3";
            this.productIDDataGridViewTextBoxColumn3.Width = 125;
            // 
            // orderIDDataGridViewTextBoxColumn5
            // 
            this.orderIDDataGridViewTextBoxColumn5.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn5.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.orderIDDataGridViewTextBoxColumn5.Name = "orderIDDataGridViewTextBoxColumn5";
            this.orderIDDataGridViewTextBoxColumn5.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn2
            // 
            this.quantityDataGridViewTextBoxColumn2.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn2.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn2.Name = "quantityDataGridViewTextBoxColumn2";
            this.quantityDataGridViewTextBoxColumn2.Width = 125;
            // 
            // unitPriceDataGridViewTextBoxColumn2
            // 
            this.unitPriceDataGridViewTextBoxColumn2.DataPropertyName = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn2.HeaderText = "UnitPrice";
            this.unitPriceDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.unitPriceDataGridViewTextBoxColumn2.Name = "unitPriceDataGridViewTextBoxColumn2";
            this.unitPriceDataGridViewTextBoxColumn2.Width = 125;
            // 
            // subTotalDataGridViewTextBoxColumn3
            // 
            this.subTotalDataGridViewTextBoxColumn3.DataPropertyName = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn3.HeaderText = "SubTotal";
            this.subTotalDataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.subTotalDataGridViewTextBoxColumn3.Name = "subTotalDataGridViewTextBoxColumn3";
            this.subTotalDataGridViewTextBoxColumn3.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn5
            // 
            this.dateDataGridViewTextBoxColumn5.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn5.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn5.Name = "dateDataGridViewTextBoxColumn5";
            this.dateDataGridViewTextBoxColumn5.Width = 125;
            // 
            // productsOrder7BindingSource
            // 
            this.productsOrder7BindingSource.DataMember = "ProductsOrder7";
            this.productsOrder7BindingSource.DataSource = this.order7;
            // 
            // order7
            // 
            this.order7.DataSetName = "Order7";
            this.order7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn4,
            this.dateDataGridViewTextBoxColumn4,
            this.employeeIDDataGridViewTextBoxColumn2,
            this.employeeNameDataGridViewTextBoxColumn2,
            this.orderTotalDataGridViewTextBoxColumn1});
            this.dataGridView7.DataSource = this.orderTable7BindingSource;
            this.dataGridView7.Location = new System.Drawing.Point(990, 682);
            this.dataGridView7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowHeadersWidth = 51;
            this.dataGridView7.RowTemplate.Height = 24;
            this.dataGridView7.Size = new System.Drawing.Size(133, 67);
            this.dataGridView7.TabIndex = 31;
            // 
            // orderIDDataGridViewTextBoxColumn4
            // 
            this.orderIDDataGridViewTextBoxColumn4.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn4.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.orderIDDataGridViewTextBoxColumn4.Name = "orderIDDataGridViewTextBoxColumn4";
            this.orderIDDataGridViewTextBoxColumn4.Width = 125;
            // 
            // dateDataGridViewTextBoxColumn4
            // 
            this.dateDataGridViewTextBoxColumn4.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn4.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dateDataGridViewTextBoxColumn4.Name = "dateDataGridViewTextBoxColumn4";
            this.dateDataGridViewTextBoxColumn4.Width = 125;
            // 
            // employeeIDDataGridViewTextBoxColumn2
            // 
            this.employeeIDDataGridViewTextBoxColumn2.DataPropertyName = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn2.HeaderText = "Employee_ID";
            this.employeeIDDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn2.Name = "employeeIDDataGridViewTextBoxColumn2";
            this.employeeIDDataGridViewTextBoxColumn2.Width = 125;
            // 
            // employeeNameDataGridViewTextBoxColumn2
            // 
            this.employeeNameDataGridViewTextBoxColumn2.DataPropertyName = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn2.HeaderText = "Employee_Name";
            this.employeeNameDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.employeeNameDataGridViewTextBoxColumn2.Name = "employeeNameDataGridViewTextBoxColumn2";
            this.employeeNameDataGridViewTextBoxColumn2.Width = 125;
            // 
            // orderTotalDataGridViewTextBoxColumn1
            // 
            this.orderTotalDataGridViewTextBoxColumn1.DataPropertyName = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn1.HeaderText = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.orderTotalDataGridViewTextBoxColumn1.Name = "orderTotalDataGridViewTextBoxColumn1";
            this.orderTotalDataGridViewTextBoxColumn1.Width = 125;
            // 
            // orderTable7BindingSource
            // 
            this.orderTable7BindingSource.DataMember = "OrderTable7";
            this.orderTable7BindingSource.DataSource = this.order7;
            // 
            // orderTable7TableAdapter
            // 
            this.orderTable7TableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager4
            // 
            this.tableAdapterManager4.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager4.OrderTable7TableAdapter = this.orderTable7TableAdapter;
            this.tableAdapterManager4.ProductsOrder7TableAdapter = this.productsOrder7TableAdapter;
            this.tableAdapterManager4.UpdateOrder = CheckMate_POS.Order7TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // productsOrder7TableAdapter
            // 
            this.productsOrder7TableAdapter.ClearBeforeFill = true;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1439, 749);
            this.Controls.Add(this.dataGridView7);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.saleeeData);
            this.Controls.Add(this.test);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.DiscounttextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.slip);
            this.Controls.Add(this.QuantityText);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.payBox);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.totalTextBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.changeBox);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.products)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salesDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleeeData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saless)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.order1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable5BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder5BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable6BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.order6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder6BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsOrder7BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.order7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderTable7BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox payBox;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox changeBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox QuantityText;
        private Products products;
        private System.Windows.Forms.BindingSource productBindingSource;
        private ProductsTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.ListBox slip;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox DiscounttextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private ActorsTableAdapters.TableAdapterManager tableAdapterManager1;
        private SalesData salesData;
        private System.Windows.Forms.BindingSource salesDataBindingSource;
        private System.Windows.Forms.BindingSource salesBindingSource;
        private SalesDataTableAdapters.SalesTableAdapter salesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleIncomeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox test;
        private System.Windows.Forms.DataGridView saleeeData;
        private Saless saless;
        private System.Windows.Forms.BindingSource productsOrderBindingSource;
        private SalessTableAdapters.ProductsOrderTableAdapter productsOrderTableAdapter;
        private SalessTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource orderTableBindingSource;
       
        private System.Windows.Forms.DataGridView dataGridView3;
        private Order order1;
        private System.Windows.Forms.BindingSource orderTable1BindingSource;
        private OrderTableAdapters.OrderTable1TableAdapter orderTable1TableAdapter;
        private OrderTableAdapters.TableAdapterManager tableAdapterManager2;
        private System.Windows.Forms.DataGridViewTextBoxColumn oRDERIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOofItemsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeNameDataGridViewTextBoxColumn;
       
        private System.Windows.Forms.BindingSource orderTable5BindingSource;
       
        private System.Windows.Forms.BindingSource productsOrder5BindingSource;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private Order6 order6;
        private System.Windows.Forms.BindingSource orderTable6BindingSource;
        private Order6TableAdapters.OrderTable6TableAdapter orderTable6TableAdapter;
        private Order6TableAdapters.TableAdapterManager tableAdapterManager3;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderTotalDataGridViewTextBoxColumn;
        private Order6TableAdapters.ProductsOrder6TableAdapter productsOrder6TableAdapter;
        private System.Windows.Forms.BindingSource productsOrder6BindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView7;
        private Order7 order7;
        private System.Windows.Forms.BindingSource orderTable7BindingSource;
        private Order7TableAdapters.OrderTable7TableAdapter orderTable7TableAdapter;
        private Order7TableAdapters.TableAdapterManager tableAdapterManager4;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeNameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderTotalDataGridViewTextBoxColumn1;
        private Order7TableAdapters.ProductsOrder7TableAdapter productsOrder7TableAdapter;
        private System.Windows.Forms.BindingSource productsOrder7BindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn5;
    }
}