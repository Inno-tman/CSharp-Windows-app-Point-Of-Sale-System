﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class EMPLOYEE : Form
    {
        public EMPLOYEE()
        {
            InitializeComponent();
        }

        private void SearchEmployeelabel_Click(object sender, EventArgs e)
        {

        }

        private void empldtlsgroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void EMPLOYEE_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'actors1.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.actors1.Employee);
            this.WindowState = FormWindowState.Maximized;



        }

        private void removebutton1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                int employeeID = Convert.ToInt32(selectedRow.Cells[0].Value);
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    int rowID = Convert.ToInt32(row.Cells[0].Value);
                    if (rowID == employeeID)
                    {
                        dataGridView1.Rows.Remove(row);
                        break;
                    }
                }
                employeeTableAdapter.Update(actors.Employee);

                MessageBox.Show("Employee data deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }



        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void EmployeeEmailtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void employeeAddresstextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void typetextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void employeeNametextBox_TextChanged(object sender, EventArgs e)
        {

           
        }

        private void SurnsmetextBox_TextChanged(object sender, EventArgs e)
        {


        }

        private void EmployeeIDtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void CitytextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void CityCodetextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numbertextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void addbutton1_Click(object sender, EventArgs e)
        {
            // Get the current text from the textBox
            string text = employeeNametextBox.Text;
            string text1 = SurnsmetextBox.Text;
            string txt = CitytextBox.Text;
            string txt1 = employeeAddresstextBox.Text;
            string txt2 = comboBox1.Text;
            // Check if the text is not empty
            if ((!string.IsNullOrEmpty(text)) || (!string.IsNullOrEmpty(text1)) || (!string.IsNullOrEmpty(txt)) || (!string.IsNullOrEmpty(txt1)) || (!string.IsNullOrEmpty(txt2)))
            {
                char c = char.ToUpper(text[0]);
                char ch = char.ToUpper(text1[0]);
                char c1 = char.ToUpper(txt[0]);
                char c2 = char.ToUpper(txt1[0]);
                char c3 = char.ToUpper(txt2[0]);
                this.employeeNametextBox.Text = c + text.Substring(1);
                SurnsmetextBox.Text = ch + text1.Substring(1);
                CitytextBox.Text = c1 + txt.Substring(1);
                employeeAddresstextBox.Text = c2 + txt1.Substring(1);
                comboBox1.Text = c3 + txt2.Substring(1);
            }

            string employeeName = employeeNametextBox.Text;
            string employeeSurname = SurnsmetextBox.Text;
            string employeeAddress = employeeAddresstextBox.Text;
            string employeeCity = CitytextBox.Text;
            int employeeCityCode;

            

            // Validate email field
            

            if (int.TryParse(CityCodetextBox2.Text, out employeeCityCode))
            {
                string employeeEmail = EmployeeEmailtextBox.Text;
                string employeeType = comboBox1.Text;
                string employeeNumber = maskedTextBox1.Text;
                DateTime hireDate = dateTimePicker1.Value;
                if (employeeType  != "Cashier" && employeeType != "Baker" && employeeType != "Cook" && employeeType != "Stock Organiser" )
                {
                    MessageBox.Show("Invalid gender value. Please select 'Stock Organiser' , 'Cook' , 'Baker', or 'Cashier'.");
                    return;
                }
                if (!employeeEmail.Contains("@"))
                {
                    MessageBox.Show("Invalid email format. Please enter a valid email address.");
                    return;
                }

                try
                {
                    Actors.EmployeeRow newRow = actors.Employee.NewEmployeeRow();

                    newRow.Name = employeeName;
                    newRow.Surname = employeeSurname;
                    newRow.Street_Address = employeeAddress;
                    newRow.City = employeeCity;
                    newRow.City_Code = employeeCityCode;
                    newRow.Email = employeeEmail;
                    newRow.Employee_Type = employeeType;
                    newRow.Phone_Number = employeeNumber;
                    newRow.Hire_Date = hireDate;
                    actors.Employee.AddEmployeeRow(newRow);

                    // Update the changes to the database using the TableAdapter
                    employeeTableAdapter.Update(actors.Employee);

                    // Optionally, display a message or perform additional actions after saving the data
                    MessageBox.Show("Employee data saved successfully!");

                    // Clear the text boxes after saving the data
                    employeeNametextBox.Clear();
                    SurnsmetextBox.Clear();
                    employeeAddresstextBox.Clear();
                    CitytextBox.Clear();
                    CityCodetextBox2.Clear();
                    EmployeeEmailtextBox.Clear();
                    maskedTextBox1.Clear();
                }
                catch (Exception ex)
                {
                    // Handle any exception that occurred during the database update
                    MessageBox.Show("Error saving employee data: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Invalid city code entered. Please enter a numeric value.");
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Manager managerForm = new Manager();
            managerForm.Show();
            this.Hide();
        }

        private void searchEmplotyeetextBox1_TextChanged(object sender, EventArgs e)
        {
            employeeTableAdapter.SerchByName(actors.Employee, searchEmplotyeetextBox1.Text);

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = employeeNametextBox.Text;
            string Surname = SurnsmetextBox.Text;
            string Address = employeeAddresstextBox.Text;
            string employeeCity = CitytextBox.Text;
            string CityCode = CityCodetextBox2.Text;
            string email = EmployeeEmailtextBox.Text;
            string number = maskedTextBox1.Text;
            
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    int rowIndex = dataGridView1.SelectedRows[0].Index; 
                    string newName = employeeNametextBox.Text.ToString();
                    string newSurname = SurnsmetextBox.Text.ToString();
                    string newCity = CitytextBox.Text.ToString();
                    string newCityCode = CityCodetextBox2.ToString();
                    string newAdress = employeeAddresstextBox.Text.ToString();
                    string newEmail = EmployeeEmailtextBox.Text.ToString();
                    string newNumber = maskedTextBox1.Text.ToString();
                    Actors.EmployeeRow Update = actors1.Employee[rowIndex];
                    if (employeeNametextBox.Text.Length > 0)
                    {
                        Update.Name = newName;
                    } else if (SurnsmetextBox.Text.Length > 0) {
                        Update.Surname = newSurname;

                    }
                    else if (CitytextBox.Text.Length > 0)
                    {
                        Update.City = newCity;

                    }
                    else if (employeeAddresstextBox.Text.Length > 0)
                    {
                        Update.Street_Address = newAdress;
                    } else if (EmployeeEmailtextBox.Text.Length > 0)
                    {
                        Update.Email = newEmail;

                    } else if (maskedTextBox1.Text.Length > 0)
                    {
                        Update.Phone_Number = newNumber;
                    }
                    else if(CityCodetextBox2.Text.Length > 0)
                        {
                        Update.City_Code = int.Parse(newCityCode);
                    }

                    employeeTableAdapter.Update(Update);
                    employeeNametextBox.Clear();
                    SurnsmetextBox.Clear();
                    CitytextBox.Clear();
                    employeeAddresstextBox.Clear();
                    EmployeeEmailtextBox.Clear();
                    maskedTextBox1.Clear();
                    CityCodetextBox2.Clear();

                }
                else
                {
                    MessageBox.Show("Please select a row to update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating Quantity data: " + ex.Message);
            }



           

        }
    }
}
