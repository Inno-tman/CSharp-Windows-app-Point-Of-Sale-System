﻿namespace CheckMate_POS
{
    partial class Manager
    {

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manager));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.salesButton = new System.Windows.Forms.Button();
            this.AddEmployeeBTN = new System.Windows.Forms.Button();
            this.addSupplierBTN = new System.Windows.Forms.Button();
            this.RemainingBTN = new System.Windows.Forms.Button();
            this.ProductsListBox = new System.Windows.Forms.GroupBox();
            this.Add = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.addQuantity = new System.Windows.Forms.TextBox();
            this.IteamSearched = new System.Windows.Forms.TextBox();
            this.itmSearchLabel = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.products = new CheckMate_POS.Products();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.productTableAdapter = new CheckMate_POS.ProductsTableAdapters.ProductTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.ProductsListBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.products)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.salesButton);
            this.panel1.Controls.Add(this.AddEmployeeBTN);
            this.panel1.Controls.Add(this.RemainingBTN);
            this.panel1.Location = new System.Drawing.Point(4, 7);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(199, 251);
            this.panel1.TabIndex = 0;
            // 
            // salesButton
            // 
            this.salesButton.BackColor = System.Drawing.Color.Peru;
            this.salesButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.salesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salesButton.Location = new System.Drawing.Point(0, 176);
            this.salesButton.Margin = new System.Windows.Forms.Padding(4);
            this.salesButton.Name = "salesButton";
            this.salesButton.Size = new System.Drawing.Size(195, 71);
            this.salesButton.TabIndex = 7;
            this.salesButton.Text = "View sales";
            this.salesButton.UseVisualStyleBackColor = false;
            this.salesButton.Click += new System.EventHandler(this.salesButton_Click);
            // 
            // AddEmployeeBTN
            // 
            this.AddEmployeeBTN.BackColor = System.Drawing.Color.Peru;
            this.AddEmployeeBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddEmployeeBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmployeeBTN.Location = new System.Drawing.Point(0, 91);
            this.AddEmployeeBTN.Margin = new System.Windows.Forms.Padding(4);
            this.AddEmployeeBTN.Name = "AddEmployeeBTN";
            this.AddEmployeeBTN.Size = new System.Drawing.Size(195, 77);
            this.AddEmployeeBTN.TabIndex = 5;
            this.AddEmployeeBTN.Text = "ADD EMPLOYEE";
            this.AddEmployeeBTN.UseVisualStyleBackColor = false;
            this.AddEmployeeBTN.Click += new System.EventHandler(this.AddEmployeeBTN_Click);
            // 
            // addSupplierBTN
            // 
            this.addSupplierBTN.BackColor = System.Drawing.Color.Peru;
            this.addSupplierBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addSupplierBTN.Location = new System.Drawing.Point(4, 534);
            this.addSupplierBTN.Margin = new System.Windows.Forms.Padding(4);
            this.addSupplierBTN.Name = "addSupplierBTN";
            this.addSupplierBTN.Size = new System.Drawing.Size(195, 60);
            this.addSupplierBTN.TabIndex = 6;
            this.addSupplierBTN.Text = "ADD SUPPLIER";
            this.addSupplierBTN.UseVisualStyleBackColor = false;
            this.addSupplierBTN.Visible = false;
            this.addSupplierBTN.Click += new System.EventHandler(this.addSupplierBTN_Click);
            // 
            // RemainingBTN
            // 
            this.RemainingBTN.BackColor = System.Drawing.Color.Peru;
            this.RemainingBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RemainingBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemainingBTN.Location = new System.Drawing.Point(0, 4);
            this.RemainingBTN.Margin = new System.Windows.Forms.Padding(4);
            this.RemainingBTN.Name = "RemainingBTN";
            this.RemainingBTN.Size = new System.Drawing.Size(195, 79);
            this.RemainingBTN.TabIndex = 1;
            this.RemainingBTN.Text = "REMAINING ITEMS";
            this.RemainingBTN.UseVisualStyleBackColor = false;
            this.RemainingBTN.Click += new System.EventHandler(this.RemainingBTN_Click);
            // 
            // ProductsListBox
            // 
            this.ProductsListBox.BackColor = System.Drawing.Color.PeachPuff;
            this.ProductsListBox.Controls.Add(this.Add);
            this.ProductsListBox.Controls.Add(this.label1);
            this.ProductsListBox.Controls.Add(this.addQuantity);
            this.ProductsListBox.Controls.Add(this.IteamSearched);
            this.ProductsListBox.Controls.Add(this.itmSearchLabel);
            this.ProductsListBox.Controls.Add(this.dataGridView1);
            this.ProductsListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductsListBox.Location = new System.Drawing.Point(207, 7);
            this.ProductsListBox.Margin = new System.Windows.Forms.Padding(4);
            this.ProductsListBox.Name = "ProductsListBox";
            this.ProductsListBox.Padding = new System.Windows.Forms.Padding(4);
            this.ProductsListBox.Size = new System.Drawing.Size(1215, 1036);
            this.ProductsListBox.TabIndex = 1;
            this.ProductsListBox.TabStop = false;
            this.ProductsListBox.Text = "Products List";
            this.ProductsListBox.Visible = false;
            this.ProductsListBox.Enter += new System.EventHandler(this.ProductsListBox_Enter);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.Peru;
            this.Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Add.Location = new System.Drawing.Point(366, 158);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(184, 39);
            this.Add.TabIndex = 5;
            this.Add.Text = "Add Quantity";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(362, 122);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Quantity";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // addQuantity
            // 
            this.addQuantity.Location = new System.Drawing.Point(456, 122);
            this.addQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.addQuantity.Name = "addQuantity";
            this.addQuantity.Size = new System.Drawing.Size(94, 28);
            this.addQuantity.TabIndex = 3;
            // 
            // IteamSearched
            // 
            this.IteamSearched.Location = new System.Drawing.Point(173, 55);
            this.IteamSearched.Margin = new System.Windows.Forms.Padding(4);
            this.IteamSearched.Name = "IteamSearched";
            this.IteamSearched.Size = new System.Drawing.Size(377, 28);
            this.IteamSearched.TabIndex = 2;
            this.toolTip1.SetToolTip(this.IteamSearched, "Enter the Item Name");
            this.IteamSearched.TextChanged += new System.EventHandler(this.IteamSearched_TextChanged);
            // 
            // itmSearchLabel
            // 
            this.itmSearchLabel.AutoSize = true;
            this.itmSearchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itmSearchLabel.Location = new System.Drawing.Point(20, 55);
            this.itmSearchLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.itmSearchLabel.Name = "itmSearchLabel";
            this.itmSearchLabel.Size = new System.Drawing.Size(110, 20);
            this.itmSearchLabel.TabIndex = 1;
            this.itmSearchLabel.Text = "Item Search";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.descriptionDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(8, 122);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(320, 807);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 125;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.Width = 125;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.products;
            // 
            // products
            // 
            this.products.DataSetName = "Products";
            this.products.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.PeachPuff;
            this.pictureBox3.Image = global::CheckMate_POS.Properties.Resources.Logout;
            this.pictureBox3.Location = new System.Drawing.Point(1775, 7);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(133, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2245, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1802, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "LogOut";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1904, 922);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.addSupplierBTN);
            this.Controls.Add(this.ProductsListBox);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Manager";
            this.Text = "Manager";
            this.Load += new System.EventHandler(this.Manager_Load);
            this.panel1.ResumeLayout(false);
            this.ProductsListBox.ResumeLayout(false);
            this.ProductsListBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.products)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button AddEmployeeBTN;
        private System.Windows.Forms.Button addSupplierBTN;
        private System.Windows.Forms.Button RemainingBTN;
        private System.Windows.Forms.GroupBox ProductsListBox;
        private System.Windows.Forms.TextBox IteamSearched;
        private System.Windows.Forms.Label itmSearchLabel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ToolTip toolTip1;
        private Products products;
        private System.Windows.Forms.BindingSource productBindingSource;
        private ProductsTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button salesButton;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox addQuantity;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
    }
}
