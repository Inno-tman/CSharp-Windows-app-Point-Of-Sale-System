﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class EmployeeHome : Form
    {
        public EmployeeHome()
        {
            InitializeComponent();
        }
        public string name { get; set; }
        public string ID { get; set; }
        public string email { get; set; }
        public string date { get; set; }
        public string phone { get; set; }
        public string address { get; set; }
        public string postal_Code { get; set; }
        public string surname { get; set; }

        private void EmployeeHome_Load(object sender, EventArgs e)
        {
            // Set the form to run in maximized mode
            this.WindowState = FormWindowState.Maximized;
            Employee_Name_TextBox.Text = name + " "+ surname;
            employee_ID_Textbox.Text = ID;
            Email_Address_TextBox.Text = email;
            Start_Date_TextBox.Text = date;
            Phone_Number_TextBox.Text = phone;
            Address_TextBox.Text = address;
            Postal_Code_TextBox.Text = postal_Code;
            label3.Text = "you logged in as: "+ name + " " + surname;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Menu menuForm = new Menu();
            menuForm.NAME = name;
            menuForm.SURNAME = surname;
            menuForm.EMAIL = email;
            menuForm.POSTAL_CODE = postal_Code;
            menuForm.ADDRESS = address;
            menuForm.ID = ID;
            menuForm.DATE = date;
            menuForm.PHONE = phone;

            this.Hide();
            menuForm.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            MyProfile MyProfileForm = new MyProfile();
            MyProfileForm.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            CustomerDetails CustomerDetails = new CustomerDetails();
            this.Hide();
            CustomerDetails.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Log Out?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            CAFE CafeForm = new CAFE();
            CafeForm.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
             
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            profilePanel.Show();
            employee_ID_Textbox.Text = ID ;
            Employee_Name_TextBox.Text = name +" "+ surname;
            Email_Address_TextBox.Text = email;
            Start_Date_TextBox.Text = date;
            Phone_Number_TextBox.Text = phone;
            Address_TextBox.Text = address;
            Postal_Code_TextBox.Text = postal_Code;
            

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void employee_ID_Textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            CAFE c = new CAFE();
            c.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
