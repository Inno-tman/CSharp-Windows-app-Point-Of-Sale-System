﻿

namespace CheckMate_POS
{
    partial class EmployeeHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
       
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmployeeHome));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.profile_label = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableAdapterManager1 = new CheckMate_POS.SalesDataTableAdapters.TableAdapterManager();
            this.customerTableAdapter1 = new CheckMate_POS.ActorsTableAdapters.CustomerTableAdapter();
            this.profilePanel = new System.Windows.Forms.Panel();
            this.Address_TextBox = new System.Windows.Forms.TextBox();
            this.Postal_Code_TextBox = new System.Windows.Forms.TextBox();
            this.Employee_Name_TextBox = new System.Windows.Forms.TextBox();
            this.Start_Date_TextBox = new System.Windows.Forms.TextBox();
            this.Email_Address_TextBox = new System.Windows.Forms.TextBox();
            this.Phone_Number_TextBox = new System.Windows.Forms.TextBox();
            this.employee_ID_Textbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.profilePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(96, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PeachPuff;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.profile_label);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1924, 114);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1822, 70);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 29);
            this.label11.TabIndex = 12;
            this.label11.Text = "LogOut";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = global::CheckMate_POS.Properties.Resources.Logout;
            this.pictureBox5.Location = new System.Drawing.Point(1841, 7);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(59, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // profile_label
            // 
            this.profile_label.AutoSize = true;
            this.profile_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profile_label.Location = new System.Drawing.Point(172, 70);
            this.profile_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.profile_label.Name = "profile_label";
            this.profile_label.Size = new System.Drawing.Size(90, 29);
            this.profile_label.TabIndex = 2;
            this.profile_label.Text = "Profile";
            this.profile_label.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = global::CheckMate_POS.Properties.Resources.logo;
            this.pictureBox3.Location = new System.Drawing.Point(158, 4);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(133, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label4.Location = new System.Drawing.Point(2364, 78);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 24);
            this.label4.TabIndex = 9;
            this.label4.Text = "Log Off";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(1257, 34);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(96, 44);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1.Location = new System.Drawing.Point(4, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 36);
            this.label1.TabIndex = 5;
            this.label1.Text = "Menu";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(2368, 7);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(80, 57);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.SalesTableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = CheckMate_POS.SalesDataTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // profilePanel
            // 
            this.profilePanel.BackColor = System.Drawing.Color.PeachPuff;
            this.profilePanel.Controls.Add(this.Address_TextBox);
            this.profilePanel.Controls.Add(this.Postal_Code_TextBox);
            this.profilePanel.Controls.Add(this.Employee_Name_TextBox);
            this.profilePanel.Controls.Add(this.Start_Date_TextBox);
            this.profilePanel.Controls.Add(this.Email_Address_TextBox);
            this.profilePanel.Controls.Add(this.Phone_Number_TextBox);
            this.profilePanel.Controls.Add(this.employee_ID_Textbox);
            this.profilePanel.Controls.Add(this.label10);
            this.profilePanel.Controls.Add(this.label9);
            this.profilePanel.Controls.Add(this.label8);
            this.profilePanel.Controls.Add(this.label7);
            this.profilePanel.Controls.Add(this.label6);
            this.profilePanel.Controls.Add(this.label5);
            this.profilePanel.Controls.Add(this.label2);
            this.profilePanel.Location = new System.Drawing.Point(7, 122);
            this.profilePanel.Margin = new System.Windows.Forms.Padding(4);
            this.profilePanel.Name = "profilePanel";
            this.profilePanel.Size = new System.Drawing.Size(608, 297);
            this.profilePanel.TabIndex = 2;
            this.profilePanel.Visible = false;
            // 
            // Address_TextBox
            // 
            this.Address_TextBox.Enabled = false;
            this.Address_TextBox.Location = new System.Drawing.Point(191, 220);
            this.Address_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Address_TextBox.Name = "Address_TextBox";
            this.Address_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Address_TextBox.TabIndex = 20;
            // 
            // Postal_Code_TextBox
            // 
            this.Postal_Code_TextBox.Enabled = false;
            this.Postal_Code_TextBox.Location = new System.Drawing.Point(191, 262);
            this.Postal_Code_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Postal_Code_TextBox.Name = "Postal_Code_TextBox";
            this.Postal_Code_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Postal_Code_TextBox.TabIndex = 19;
            // 
            // Employee_Name_TextBox
            // 
            this.Employee_Name_TextBox.Enabled = false;
            this.Employee_Name_TextBox.Location = new System.Drawing.Point(191, 52);
            this.Employee_Name_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Employee_Name_TextBox.Name = "Employee_Name_TextBox";
            this.Employee_Name_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Employee_Name_TextBox.TabIndex = 18;
            // 
            // Start_Date_TextBox
            // 
            this.Start_Date_TextBox.Enabled = false;
            this.Start_Date_TextBox.Location = new System.Drawing.Point(191, 95);
            this.Start_Date_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Start_Date_TextBox.Name = "Start_Date_TextBox";
            this.Start_Date_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Start_Date_TextBox.TabIndex = 17;
            // 
            // Email_Address_TextBox
            // 
            this.Email_Address_TextBox.Enabled = false;
            this.Email_Address_TextBox.Location = new System.Drawing.Point(191, 177);
            this.Email_Address_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Email_Address_TextBox.Name = "Email_Address_TextBox";
            this.Email_Address_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Email_Address_TextBox.TabIndex = 16;
            // 
            // Phone_Number_TextBox
            // 
            this.Phone_Number_TextBox.Enabled = false;
            this.Phone_Number_TextBox.Location = new System.Drawing.Point(191, 137);
            this.Phone_Number_TextBox.Margin = new System.Windows.Forms.Padding(4);
            this.Phone_Number_TextBox.Name = "Phone_Number_TextBox";
            this.Phone_Number_TextBox.Size = new System.Drawing.Size(412, 22);
            this.Phone_Number_TextBox.TabIndex = 15;
            // 
            // employee_ID_Textbox
            // 
            this.employee_ID_Textbox.Enabled = false;
            this.employee_ID_Textbox.Location = new System.Drawing.Point(191, 10);
            this.employee_ID_Textbox.Margin = new System.Windows.Forms.Padding(4);
            this.employee_ID_Textbox.Name = "employee_ID_Textbox";
            this.employee_ID_Textbox.Size = new System.Drawing.Size(412, 22);
            this.employee_ID_Textbox.TabIndex = 14;
            this.employee_ID_Textbox.TextChanged += new System.EventHandler(this.employee_ID_Textbox_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(4, 182);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 6;
            this.label10.Text = "Email_Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(4, 225);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 20);
            this.label9.TabIndex = 5;
            this.label9.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(4, 267);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Postal_Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(4, 142);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Phone_Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 57);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 100);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Start_Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(4, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee_ID";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(382, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 13;
            // 
            //// EmployeeHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 821);
            this.Controls.Add(this.profilePanel);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EmployeeHome";
            this.Text = "EmployeeHome";
            this.Load += new System.EventHandler(this.EmployeeHome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.profilePanel.ResumeLayout(false);
            this.profilePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private SalesDataTableAdapters.TableAdapterManager tableAdapterManager1;
        private ActorsTableAdapters.CustomerTableAdapter customerTableAdapter1;
        private System.Windows.Forms.Label profile_label;
        private System.Windows.Forms.Panel profilePanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Address_TextBox;
        private System.Windows.Forms.TextBox Postal_Code_TextBox;
        private System.Windows.Forms.TextBox Employee_Name_TextBox;
        private System.Windows.Forms.TextBox Start_Date_TextBox;
        private System.Windows.Forms.TextBox Email_Address_TextBox;
        private System.Windows.Forms.TextBox Phone_Number_TextBox;
        public System.Windows.Forms.TextBox employee_ID_Textbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
    }
}