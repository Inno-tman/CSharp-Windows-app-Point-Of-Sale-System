﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckMate_POS
{
    public partial class CAFE : Form
    {
        public static int prof;

        public string p;
        public CAFE()
        {
            InitializeComponent();
        }
        Actors actors = new Actors();
        ActorsTableAdapters.EmployeeTableAdapter employeeTableAdapter = new ActorsTableAdapters.EmployeeTableAdapter();
        public string name { get; private set; }
        public int ID;
        public string email { get; private set; }
        public string date { get; private set; }
        public string phone { get; private set; }
        public string address { get; private set; }
        public string surname { get; private set; }

        public string postal_Code { get; private set; }
        public string combinedUsername;


        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        Label lbl = new Label();

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox3.Text;

            Actors actors = new Actors();
            ActorsTableAdapters.EmployeeTableAdapter employeeTableAdapter = new ActorsTableAdapters.EmployeeTableAdapter();

            // Fill the dataset with data from the Employee table
            //employeeTableAdapter.Fill(actors.Employee);
            employeeTableAdapter.SerchByName(actors.Employee,Name);
            employeeTableAdapter.FillByID(actors.Employee);





            // Combine the "Name" field and "Employee_ID" field to form the username
             combinedUsername = string.Empty;
            
            var employee = actors.Employee.FirstOrDefault(emp => emp.Name + emp.Employee_ID.ToString() == username);
            prof = 3;
           if (employee != null)
           {
                name = employee.Name.ToString();
                ID = int.Parse(employee.Employee_ID.ToString());
                email = employee.Email.ToString();
                address = employee.Street_Address.ToString();
                postal_Code = employee.City_Code.ToString();
                phone = employee.Phone_Number.ToString();
                date = employee.Hire_Date.ToString();
                surname = employee.Surname.ToString();

                combinedUsername = name + ID;
           }


            if (username == "Manager" && password == "1234")
            {
                // Create an instance of the Manager form
                Manager managerForm = new Manager();
                managerForm.Show();
                this.Hide();
            }
            else if (username == combinedUsername && password == "1234") 

                //    new EmployeeHome().employee_ID_Textbox_TextChanged(sender, e);
               

                
            {
                new EmployeeHome().employee_ID_Textbox.Text = employee.Employee_ID.ToString();

                if (employee.Employee_Type=="Cashier")
                {

                    // Create an instance of the EmployeeHome form
                    EmployeeHome homeForm = new EmployeeHome();
                    Menu m = new Menu();
                    m.NAME = name;
                    m.SURNAME = surname;
                    homeForm.name = name;
                    homeForm.ID = ID.ToString();
                    homeForm.email = email.ToString();
                    homeForm.address = address.ToString();
                    homeForm.postal_Code = postal_Code.ToString();
                    homeForm.phone = phone.ToString();
                    homeForm.date = date.ToString();
                    homeForm.surname = surname;


                    homeForm.Show();
              
                    this.Hide();
                    MessageBox.Show("Welcome to the Checkmate Home Page " + employee.Name + " " + employee.Surname);
                    p = employee.Employee_ID.ToString();
                    lbl.Text = "You're logged in as " + employee.Name + " " + employee.Surname;
                    lbl.AutoSize = false;
                    lbl.Size.Equals(15);
                    lbl.Dock = DockStyle.Bottom;
                    homeForm.Controls.Add(lbl);
                }
                else
                {
                    // Display an error message or perform any other action for invalid credentials
                    MessageBox.Show("This username doesn't have access to the Checkmate system");
                }
                }
            
            else
            {
                // Display an error message or perform any other action for invalid credentials
                MessageBox.Show("Invalid username or password");
            }



        }


        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CAFE_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lgnbutton2_Click(object sender, EventArgs e)
        {
            panel2.Show();
           // this.Hide();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CAFE_Load_1(object sender, EventArgs e)
        {

        }
    }
}
